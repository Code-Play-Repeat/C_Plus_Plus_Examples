#include <iostream>
#include <vector>
#include <string>

using namespace std;

class StringVector : public vector<void*>
{
public:
void push_back(string* str){
	vector<void*>::push_back(str);
	}
  string* operator[] (int i) {
	string* str = (string*)(*(vector<void*>*)this)[i];
	return str;
	}

};		

int main () {
	void* vp;
	StringVector sv;
	sv.push_back(vp); // Gives a compile time error because a void* can be pointing to anything. The compiler doesn't know whether it
										// is a string* or not so it flags it as unsafe and prevents the program from compiling.

}		
