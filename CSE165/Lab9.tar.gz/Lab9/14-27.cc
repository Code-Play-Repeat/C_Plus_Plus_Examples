#include <iostream>
using namespace std;

class Subject {
public:
	void f() {cout <<"Subject.f()\n";}
	void g() {cout <<"Subject.g()\n";}
	void h() {cout <<"Subject.h()\n";}
};

class Proxy : public Subject {
Subject* s;
public:
	void f() {s->f();}
	void g() {s->g();}
	void h() {s->h();}

	Proxy () {cout << "Proxy1\n";} // don't quite understand what the difference between the two implementations is
	Proxy (Subject* ns) { 				// my first implementation uses the pointer to subject built-in the proxy to call subject's functions within proxy's functions
		cout <<"Proxy2\n"; 					// my second implementation uses the pointer passed to proxy to call the functions within Proxy's non-default constructor.
		ns->f();	
		ns->g();
		ns->h();
	}
	
};

class Implementation1 : public Subject {
Subject* s;
public:
	void f() {s->f();}
	void g() {s->g();}
	void h() {s->h();}
	Implementation1 () {cout <<"Implementation1\n";}
};

class Implementation2 : public Subject {
Subject *s;
public:
	Implementation2 (Subject* ns) {
		cout <<"Implementation2\n";
		ns->f();	
		ns->g();
		ns->h();
	}
};

int main (){
	Subject* s = new Subject();
	Implementation1 i1;
	i1.f();
	i1.g();
	i1.h();
	Implementation2 i2 (s);
	Proxy p1; // Dynamically changed proxy so that you can create a default proxy and call its functions or create a proxy with a subject pointer passed to it where the functions get called in proxy's non-default constructor.
	p1.f();
	p1.g();
	p1.h();
	Proxy p2(s);
	
}
