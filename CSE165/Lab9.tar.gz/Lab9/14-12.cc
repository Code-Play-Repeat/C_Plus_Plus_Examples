#include <iostream>
#include <vector>
#include <string>
#include <sstream>

using namespace std;
class Asteroid {
	public:
		Asteroid () {}
		void print () { cout << " Asteroid " << endl;}
};

class AsteroidVector : public vector<void*>
{
public:
  AsteroidVector () {}
void push_back(Asteroid* ast){
	vector<void*>::push_back (ast);
	}
  Asteroid* operator[] (int i) {
	Asteroid* ast = (Asteroid*)(*(vector<void*>*)this)[i];
	return ast;
	}
size_type size () {
	return (*(vector<void*>*)this).size();
}
	void pop_back () {
	if (!(*(vector<void*>*)this).empty())
	(*(vector<void*>*)this).pop_back();
}

};

int main () {
	AsteroidVector asteroidVector;
	for(int i = 0; i < 25; i++)
	{
		Asteroid* ast = new Asteroid;
		asteroidVector.push_back(ast);
	}
	for(int j = 0; j < (int)asteroidVector.size(); j++)
		cout << "asteroidVector[" << j << "] = " << *(int*)asteroidVector[j] << endl;
	// Clean up:
	for(int k = 0; k < (int)asteroidVector.size(); k++)
		asteroidVector.pop_back();
}		
