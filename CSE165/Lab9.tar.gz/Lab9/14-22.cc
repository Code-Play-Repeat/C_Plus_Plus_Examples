#include <iostream>
using namespace std;

enum note { middleC, Csharp, Cflat }; 
class Instrument {
public:
  void virtual play(note) const {cout << "Instrument" << endl;}
};

class Wind : public Instrument {
  void play(note) const {cout << "Wind Instrument" << endl;}
};
void tune(Instrument& i) {

  i.play(middleC);
}

int main() {
  Wind flute;
  tune(flute); // Upcasting
  // The function call play refers to the Instrument play function call and the desired behavior would most likely be the Wind function call.
  // This has to deal with upcasting because inside the function tune the parameter is an Instrument reference As a result the argument is refered
  // to as an Instrument object and not as a Wind object.
  // After virtual is applied to the play function of Instrument it allows the play function to be overridden in the derived class Wind so now
  // the desired behavior is achieved.
} ///:~
