#include <iostream>
using namespace std;

class SpaceShip {
public:
	void fly () { cout << "Flying..." << endl;}
};

class Shuttle : public SpaceShip  {
public:
	void land () { cout << "Landing..." << endl; }
};

int main () {

	Shuttle sh;
	SpaceShip* sp = &sh;
	
 	  sp->land(); // When upcasting the compiler casts the pointer as the type of the Base class. So it only knows the member functions and/or data
								// of the Base class because it is casted as type of Base class. Since the function land does not exist in the class spaceship, the
								// compiler says that function doesn't exist.  Even though the pointer is a pointer to a reference of a shuttle object.

}
