#include <iostream>
using namespace std;

class Base1 {
public:
  Base1 () { cout << "Base1 constructor\n"; }
  ~Base1 () { cout << "Base1 destructor\n"; }
};

class Derived1 : public Base1 {
public:
  Derived1() {
    cout << "Derived1 constructor\n";
  }
  ~Derived1() {
    cout << "Derived1 destructor\n";
  }
};

class Derived2 : public Derived1 {
public:
  Derived2(){
    cout << "Derived2 constructor\n";
  }
  ~Derived2() {
    cout << "Derived2 destructor\n";
  }
};

class Derived3 : public Derived2 {
public:
  Derived3(){
    cout << "Derived3 constructor\n";
  }
  ~Derived3() {
    cout << "Derived3 destructor\n";
  }
};

int main() {
  Derived3 d3;
} 
/* 
Output:
Base1 constructor // Before constructor of Derived3 can be called the class constructor at the highest-level of the heirarchy must be called.
Derived1 constructor // Then next class constructor in the heirarchy is called.
Derived2 constructor // Followed by the next class constructor in the heirarchy.
Derived3 constructor // Then after the class constructors at the highest-levels are called the lowest-level constructor can be called.
Derived3 destructor  // The destruction of those objects starts at the lowest-level class because thats the last to be created.
Derived2 destructor  // Then the class higher than the lowest-level class is destroyed.
Derived1 destructor // Then the class above that is destroyed.
Base1 destructor    // The final class to be destroyed is the base class because the derived classes depend on the base class.

// The order is this way because the base classes need to be created first because all the derived classes depend on the base classes they are derived from.
// They depend on the base classes because they inherit certain member functions and data that comes from the base classes so the base classes need to be
// the first to be created and the last to be destroyed.
*/
