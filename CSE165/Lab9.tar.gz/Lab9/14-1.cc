
#include <iostream>
using namespace std;

class Vehicle {
public:
	int id;
	Vehicle (int i) : id(i) { cout << "Vehicle #" << id << " being created." << endl;} 
  	Vehicle () : id(0) { cout << "Vehicle #" << id << " being created." << endl;}
	void maintenance () const { cout << "Maintaining vehicle." << endl;}
 	void tuneUp () const { cout << "Tuning vehicle." << endl;}
	~Vehicle () {cout << "Vehicle #" << id << " being destroyed." << endl;}
	
};

class Engine {
public:
  void start() const {}
  void rev() const {}
  void stop() const {}
};

class Wheel {
public:
  void inflate(int psi) const {}
};

class Window {
public:
  void rollup() const {}
  void rolldown() const {}
};

class Door {
public:
  Window window;
  void open() const {}
  void close() const {}
};

class Car : public Vehicle {
public:
  int id;
  Car (int i) : id(i), Vehicle (i){ cout << "Car #" << id << " being created." << endl;}
  Car () : id(0), Vehicle(0) { cout << "Car #" << id << " being created." << endl; }
  ~Car() { cout << "Car #" << id << " being destroyed." << endl;}
  Engine engine;
  Wheel wheel[4];
  Door left, right; // 2-door
};

int main() {
  Car car;
  car.left.window.rollup();
  car.wheel[0].inflate(72);
} ///:~
