#include <iostream>
using namespace std;

class Parent {
  int i;
public:
  Parent(int ii) : i(ii) {
    cout << "Parent(int ii)\n";
  }
  Parent(const Parent& b) : i(b.i) {
    cout << "Parent(const Parent&)\n";
  }
  Parent() : i(0) { cout << "Parent()\n"; }
  friend ostream&
    operator<<(ostream& os, const Parent& b) {
    return os << "Parent: " << b.i << endl;
  }
};

class Member {
public:
  int i;
  Member(int ii) : i(ii) {
    cout << "Member(int ii)\n";
  }
  Member(const Member& m) : i(m.i) {
    cout << "Member(const Member&)\n";
  }
  friend ostream&
    operator<<(ostream& os, const Member& m) {
    return os << "Member: " << m.i << endl;
  }
};

class Child : public Parent {
  int i;
  Member m;
public:
  Child(int ii) : Parent(ii), i(ii), m(ii) {
    cout << "Child(int ii)\n";
  }
  friend ostream&
    operator<<(ostream& os, const Child& c){
    return os << (Parent&)c << c.m
              << "Child: " << c.i << endl;
  }
};

class Child2 : public Child {
Member m;
public:
	Child2(int ii) : Child(ii), m(ii) { cout << "Child2(int ii)" << endl;}
	Child2(const Child2& f) : Child(f.m.i), m(f.m.i) { cout <<"Child2(const Child2&)" << endl;}
  
	Child2& operator=(const Child2& right) {if (this == &right) return *this; m = right.m; Child::operator=(right); return *this;}
	friend ostream& operator<<(ostream& os, const Child2& f){return os << (Child&)f << f.m << "Child2: " << f.m.i << endl;}
};

int main() {
  Child2 c(3);
  Child2 c2 = c; 
  cout << "values in c2: \n" << c2 << endl;
} ///:~
