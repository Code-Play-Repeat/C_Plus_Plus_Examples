#include <iostream>
using namespace std;

class A {
  int i;
public:
  A(int ii) : i(ii) { cout << "A constructor\n";}
  ~A() {cout << "A destructor\n";}
  void f() const {cout << i << endl;}
};

class B : public A {
  int i;
public:
  B(int ii) : i(ii), A(ii)  {cout << "B constructor\n";}
  ~B() {cout << "B destructor\n";}
  void f() const {cout << i << endl;}
};

class C : public B {
  A a; B b;
public:
  C(int ii) : B(ii), a(ii), b(ii) {cout << "C constructor\n";}
  ~C() { cout << "C destructor\n";} // Calls ~A() and ~B()
  void f() const {  // Redefinition
    a.f();
    B::f();
    b.f();
  }
};

int main() {
  C c(47);
  c.f();
} ///:~
