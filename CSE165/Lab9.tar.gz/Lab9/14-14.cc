#include <iostream>
#include <string>
using namespace std;

class Traveler {
string st;
public:
	Traveler(string str) { st = str; cout << st << endl;}

	Traveler(Traveler& t) { st = t.st; cout << st << endl;}
	
	Traveler& operator= (Traveler& traveler){ if (this == &traveler) return *this; this->st = traveler.st; return *this;}
	
};

class Pager {
string st;
public:
	Pager(string str) { st = str; cout << st << endl; }

	Pager(Pager& t) { st = t.st; cout << st << endl;}
	
	Pager& operator= (Pager& pager){ if (this == &pager) return *this; this->st = pager.st; return *this;}

};

class BusinessTraveler: public Traveler {
string st;
Pager page;
public:
	BusinessTraveler () : Traveler ("empty"), page ("empty") { st = "empty"; cout << st << endl;}
	BusinessTraveler(string str) : Traveler(str), page(str) { st = str; cout << st << endl;}

	BusinessTraveler(BusinessTraveler& t) : Traveler(t.st), page(t.st) { st = t.st; cout << st << endl;}
	
	BusinessTraveler& operator= (BusinessTraveler& businessTraveler){ if (this == &businessTraveler) return *this; this->st = businessTraveler.st; return *this;}

};

int main () {
	BusinessTraveler bt;
	BusinessTraveler bt2 ("Hello ");
	BusinessTraveler bt3 = bt;
	Traveler t1 ("Yo ");
	Traveler t2 = t1;
	Pager p1 ("Paging... ");
	Pager p2 = p1;
}
