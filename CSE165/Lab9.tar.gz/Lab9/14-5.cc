#include <iostream>
using namespace std;
class A {
  int i;
public:
  A(int ii) : i(ii) {cout << "A constructor\n";}
  ~A() {cout << "A destructor\n";}
  void f() const { cout << i << endl;}
};

class B {
  int i;
public:
  B(int ii) : i(ii) {cout << "B constructor\n";}
  ~B() {cout << "B destructor\n";}
  void f() const { cout << i << endl;}
};

class C : public B {
  A a;
public:
  C(int ii) : B(ii), a(ii) {cout << "C constructor\n";}
  ~C() {cout << "C destructor\n";} // Calls ~A() and ~B()
  void f() const {  // Redefinition
    a.f();
    B::f();
  }
};

class D : public B {
C c;
public:
  D(int ii) : B(ii), c(ii) {cout << "D constructor\n";}
  ~D() {cout << "D destructor\n"; }
};

int main() {
  D d(47);
} ///:~
