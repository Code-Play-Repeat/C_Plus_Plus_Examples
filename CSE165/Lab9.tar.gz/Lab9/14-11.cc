
#include "require.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstring> // 'mem' functions
using namespace std;

class PStash {
	int quantity; // Number of storage spaces
	int next; // Next empty space
	// Pointer storage:
	void** storage;
	void inflate(int increase);
public:
	PStash() : quantity(0), storage(0), next(0) {}
	~PStash();
	int add(void* element);
	void* operator[](int index) const; // Fetch
	// Remove the reference from this PStash:
	void* remove(int index);
	// Number of elements in Stash:
	int count() const { return next; }
};

int PStash::add(void* element) {
	const int inflateSize = 10;
	if(next >= quantity)
		inflate(inflateSize);
	storage[next++] = element;
	return(next - 1); // Index number
}
// No ownership:
PStash::~PStash() {
	for(int i = 0; i < next; i++)
		require(storage[i] == 0,
				"PStash not cleaned up");
	delete []storage;
}
// Operator overloading replacement for fetch
void* PStash::operator[](int index) const {
	require(index >= 0,
			"PStash::operator[] index negative");
	if(index >= next)
		return 0; // To indicate the end
	// Produce pointer to desired element:
	return storage[index];
}
void* PStash::remove(int index) {
	void* v = operator[](index);
	// "Remove" the pointer:
	if(v != 0) storage[index] = 0;
	return v;
}
void PStash::inflate(int increase) {
	const int psz = sizeof(void*);
	void** st = new void*[quantity + increase];
	memset(st, 0, (quantity + increase) * psz);
	memcpy(st, storage, quantity * psz);
	quantity += increase;
	delete []storage; // Old storage
	storage = st; // Point to new memory
} ///:~

class Asteroid : public PStash {
public: 
};

int main() {
	Asteroid asteroidStash;
	// 'new' works with built-in types, too. Note
	// the "pseudo-constructor" syntax:
	for(int i = 0; i < 25; i++)
		asteroidStash.add(new Asteroid());
	for(int j = 0; j < asteroidStash.count(); j++)
		cout << "asteroidStash[" << j << "] = " << *(int*)asteroidStash[j] << endl;
	// Clean up:
	for(int k = 0; k < asteroidStash.count(); k++)
		delete asteroidStash.remove(k);
	ifstream in ("14-11.cc");
	assure(in, "14-11.cc");
	PStash stringStash;
	string line;
	while(getline(in, line))
		stringStash.add(new string(line));
	// Print out the strings:
	for(int u = 0; stringStash[u]; u++)
		cout << "stringStash[" << u << "] = " << *(string*)stringStash[u] << endl;
	// Clean up:
	for(int v = 0; v < stringStash.count(); v++)
		delete (string*)stringStash.remove(v);
} ///:~



