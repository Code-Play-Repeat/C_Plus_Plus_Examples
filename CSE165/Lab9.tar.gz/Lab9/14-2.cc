#include <iostream>
using namespace std;

class A {
public:
	A(){cout << "A is being created." << endl;} // automatically called by the compiler when creating object of class C
};

class B {
public:
	B() {cout << "B is being created." << endl;} // Is only called because a member object is being created 
						     // when an object of class C is being created
};

class C : public A {
public:
	B b;
};

int main () {
C c; 
//  Not defining and declaring a default constructor in derived class C forces the compiler to automatically call the parent class's constructor.
// The parent class's constructor then is automatically assigned to the derived class C.
//  The constructor of member class B is called only because it is a member of class C and its object is being created in C.
}
