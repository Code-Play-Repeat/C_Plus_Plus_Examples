//: C07:Stash3.cpp {O}
// Function overloading
#include "Stash3.h"
#include "require.h"
#include <iostream>
#include <cassert>

using namespace std;
const int increment = 100;
Stash3::Stash3(int sz = 0, int initQuantity = 0) {
	size = sz;
	quantity = 0;
	next = 0;
	storage = 0;
	inflate(initQuantity);
}
Stash3::~Stash3() {
	if(storage != 0) {
		cout << "freeing storage" << endl;
		delete []storage;
	}
}
int Stash3::add(void* element) {
	if(next >= quantity) // Enough space left?
		inflate(increment);
	// Copy element into storage,
	// starting at next empty space:
	int startBytes = next * size;
	unsigned char* e = (unsigned char*)element;
	for(int i = 0; i < size; i++)
		storage[startBytes + i] = e[i];
	next++;
	return(next - 1); // Index number
}
void* Stash3::fetch(int index) {
	require(0 <= index, "Stash3::fetch (-)index");
	if(index >= next)
		return 0; // To indicate the end
	// Produce pointer to desired element:
	return &(storage[index * size]);
}

int Stash3::count() {
	return next; // Number of elements in CStash
}
void Stash3::inflate(int increase) {
	assert(increase >= 0);
	if(increase == 0) return;
	int newQuantity = quantity + increase;
	int newBytes = newQuantity * size;
	int oldBytes = quantity * size;
	unsigned char* b = new unsigned char[newBytes];
	for(int i = 0; i < oldBytes; i++)
		b[i] = storage[i]; // Copy old to new
	delete [](storage); // Release old storage
	storage = b; // Point to new memory
	quantity = newQuantity; // Adjust the size
} ///:~

