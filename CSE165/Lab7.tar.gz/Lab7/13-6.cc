#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "PStash.cc"
using namespace std;

class Counted 
{
public:
	int id;
	static int count;
	Counted(): id(count++) 
	{
		cout << id <<" it is being created" <<  endl;
	}
	~Counted()
	{
		cout << id <<" it is being destoryed" << endl;	
	}
	void f() { cout << id << endl;}	

};

int Counted::count = 1;

int main (int argc, char** argv)
{
	PStash countStash;
	int n = atoi(argv[1]);

	for (int i = 0; i < n; i++)
		countStash.add (new Counted());  // These for loops seem rather redundant. Could just get rid of the hassle with one.
	for (int j = 0; j < countStash.count(); j++)
		((Counted*)countStash[j])->f();
	for(int k = 0; k < countStash.count(); k++)
		delete (Counted*)countStash.remove(k);


}

