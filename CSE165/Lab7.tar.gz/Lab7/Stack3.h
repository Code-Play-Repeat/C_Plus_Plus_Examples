#ifndef STACK3_H
#define STACK3_H
class Stack3 {
	struct Link {
		void* data;
		Link* next;
		Link(void* dat, Link* nxt);
		~Link();
	}* head;
public:
	Stack3();
	Stack3(Stack3* stk[], int size);
	~Stack3();
	void push(void* dat);
	void* peek();
	void* pop();
};
#endif // Stack3_H ///:~

