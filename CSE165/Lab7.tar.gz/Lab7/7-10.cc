//: C07:Stash3Test.cpp
//{L} Stash3
// Function overloading
#include "Mem.h"
#include "require.h"
#include <cassert>
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

class Stash {
	int size;
	// Size of each space
	int quantity; // Number of storage spaces
	int next;
	// Next empty space
	// Dynamically allocated array of bytes:
	Mem* storage;
	void inflate(int increase);
public:
	Stash(int size, int initQuantity = 0);
	~Stash();
	int add(void* element);
	void* fetch(int index);
	int count();
};

const int increment = 100;
Stash::Stash(int sz, int initQuantity) {
	size = sz;
	quantity = 0;
	next = 0;
	storage = 0;
	inflate(initQuantity);
}
Stash::~Stash() {
	if(storage != 0) {
		cout << "freeing storage" << endl;
		delete []storage;
	}
}
int Stash::add(void* element) {
	if(next >= quantity) // Enough space left?
		inflate(increment);
	// Copy element into storage,
	// starting at next empty space:
	int startBytes = next * size;
	Mem* e = (Mem*)element;
	for(int i = 0; i < size; i++)
		storage[startBytes + i] = e[i];
	next++;
	return(next - 1); // Index number
}
void* Stash::fetch(int index) {
	require(0 <= index, "Stash::fetch (-)index");
	if(index >= next)
		return 0; // To indicate the end
	// Produce pointer to desired element:
	return &(storage[index * size]);
}

int Stash::count() {
	return next; // Number of elements in CStash
}
void Stash::inflate(int increase) {
	assert(increase >= 0);
	if(increase == 0) return;
	int newQuantity = quantity + increase;
	int newBytes = newQuantity * size;
	int oldBytes = quantity * size;
	Mem* b = new Mem[newBytes];
	for(int i = 0; i < oldBytes; i++)
		b[i] = storage[i]; // Copy old to new
	delete [](storage); // Release old storage
	storage = b; // Point to new memory
	quantity = newQuantity; // Adjust the size
} ///:~


int main() {
	Stash intStash(sizeof(int));
	for(int i = 0; i < 100; i++)
		intStash.add(&i);
	for(int j = 0; j < intStash.count(); j++)
		cout << "intStash.fetch(" << j << ") = " << *(int*)intStash.fetch(j) << endl;
	const int bufsize = 80;
	Stash stringStash(sizeof(char) * bufsize, 100);
	ifstream in("7-10.cc");
	assure(in, "7-10.cc");
	string line;
	while(getline(in, line))
		stringStash.add((char*)line.c_str());
	int k = 0;
	char* cp;
	while((cp = (char*)stringStash.fetch(k++))!=0)
		cout << "stringStash.fetch(" << k << ") = " << cp << endl;
} ///:~

