#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;

class Member {
	public:
		//void memFun(int i = 1, int j = 2, int k = 3){cout << i << " " << j << " " << k << endl;} // does not change main.
		void memFun(){cout << "call with 0 parameter" << endl;}
		void memFun(int i){ cout << "call with 1 parameter" << endl;}
		void memFun(int i, int j) { cout << "call with 2 parameter" << endl;}
		void memFun(int i, int j, int k) { cout << "call with 3 parameter" << endl;}
};

int main (int argc, char** argv){
Member memb;

memb.memFun();
memb.memFun(atoi(argv[1]));
memb.memFun(atoi(argv[1]), atoi(argv[2]));
memb.memFun(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]));
}
