#include <iostream>
#include <string>
#include <fstream>
using namespace std;
class Message {
	string strObj;
	public:
		
		Message(){}
		Message(string str = "internal message\n") 
		{
			strObj = str;
		
		} 		
		void print(){cout << strObj << endl;}
		void print(string str) {cout << str << strObj << endl;}
		
};

int main (int argc, char** argv){
string s(argv[1]);
string s2(argv[2]);
Message msg (s);
msg.print();
msg.print(s2);

}
