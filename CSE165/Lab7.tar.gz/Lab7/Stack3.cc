//: C06:Stack3.cpp {O}
// Constructors/destructors
#include "Stack3.h"
#include "require.h"
using namespace std;
Stack3::Link::Link(void* dat, Link* nxt) {
	data = dat;
	next = nxt;
}
Stack3::Link::~Link() { }
Stack3::Stack3() { head = 0; }
Stack3::Stack3(Stack3* stk[] = 0, int size = 0)
{
	for (int i = 0; i < size; i++)
		head = new Link(stk[i],head);
}

void Stack3::push(void* dat) {
	head = new Link(dat,head);
}
void* Stack3::peek() {
	require(head != 0, "Stack empty");
	return head->data;
}
void* Stack3::pop() {
	if(head == 0) return 0;
	void* result = head->data;
	Link* oldHead = head;
	head = head->next;
	delete oldHead;
	return result;
}

Stack3::~Stack3() {
	require(head == 0, "Stack not empty");
} ///:~

