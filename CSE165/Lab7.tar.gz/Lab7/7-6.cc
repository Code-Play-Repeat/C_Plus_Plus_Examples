//: C07:Stash3Test.cpp
//{L} Stash3
// Function overloading
#include "Stash3.h"
#include "require.h"
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

int main() {
	Stash3 intStash3(sizeof(int),0);
	for(int i = 0; i < 100; i++)
		intStash3.add(&i);
	for(int j = 0; j < intStash3.count(); j++)
		cout << "intStash3.fetch(" << j << ") = " << *(int*)intStash3.fetch(j) << endl;
	const int bufsize = 80;
	Stash3 stringStash3(sizeof(char) * bufsize, 100);
	ifstream in("7-6.cc");
	assure(in, "7-6.cc");
	string line;
	while(getline(in, line))
		stringStash3.add((char*)line.c_str());
	int k = 0;
	char* cp;
	while((cp = (char*)stringStash3.fetch(k++))!=0)
		cout << "stringStash3.fetch(" << k << ") = " << cp << endl;
} ///:~

