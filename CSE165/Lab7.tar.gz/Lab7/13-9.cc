#include <iostream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

class Counted 
{
public:
	int id;
	static int count;
	Counted(int nId): id(nId)
	{
		cout << id <<" it is being created" <<  endl;
	}
	~Counted()
	{
		cout << id <<" it is being destroyed" << endl;	
	}
	void f() { cout << id << endl;}	

};

int Counted::count = 1;

int main (int argc, char** argv)
{
	int id = atoi(argv[1]);
	Counted* countObj = new Counted(id);
	delete (void*) countObj; // Warning occurs and the object only gets created but not destroyed. This is because now that it is a void* it could be
				// pointing to anything and thus the compiler doesn't know what to delete.
	
}

