#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

class Counted 
{
public:
	int id;
	static int count;
	Counted(): id(count++) 
	{
		cout << id <<" it is being created" <<  endl;
	}
	~Counted()
	{
		cout << id << " it is being destoryed" << endl;	
	}		

};

int Counted::count = 1;

int main (int argc, char** argv)
{
	int n = atoi(argv[1]);

	for (int i = 1; i <= n; i++)
		Counted countObj;

}

