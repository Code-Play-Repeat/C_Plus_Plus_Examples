//: C06:Stack3Test.cpp
//{L} Stack3
//{T} Stack3Test.cpp
// Constructors/destructors
#include "Stack3.h"
#include "require.h"
#include <fstream>
#include <iostream>
#include <string>
using namespace std;
int main(int argc, char* argv[]) {
	ifstream in("7-7.cc");
	assure(in, "7-7.cc");
	Stack3 textlines;
	string line;
	// Read file and store lines in the Stack3:
	while(getline(in, line))
		textlines.push(new string(line));
	// Pop the lines from the Stack3 and print them:
	string* s;
	while((s = (string*)textlines.pop()) != 0) {
		cout << *s << endl;
		delete s;
	}


} ///:~

