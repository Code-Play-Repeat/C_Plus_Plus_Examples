#include <iostream>
#include <string>
#include <fstream>
using namespace std;
class Text {
	public:
		string strObj;
		Text(){}
		Text(string str) 
		{
			char * st= new char[str.size() + 1];
			copy (str.begin(), str.end(), st);
			st[str.size()] = '\0';
			ifstream in(st);
			string line;
			while(getline(in, line))
				strObj += line;
			delete[] st;
		
		} 		
		string contents(){return strObj;}
};

int main (int argc, char** argv){
string sFile(argv[1]);
Text textFile (sFile);
cout << textFile.contents() << endl;
}
