#include "Mem2.h"
#include <cstring>
using namespace std;
Mem2::Mem2() { mem =0; size = 0;}
Mem2::Mem2(int sz = 0) {
	mem = 0;
	size = 0;
	ensureMinSize(sz);
}
Mem2::~Mem2() { delete []mem; }

int Mem2::msize() { return size; }

void Mem2::ensureMinSize(int minSize) {
	if(size < minSize) {
		byte* newmem = new byte[minSize];
		memset(newmem + size, 0, minSize - size);
		memcpy(newmem, mem, size);
		delete []mem;
		mem = newmem;
		size = minSize;
	}
}
byte* Mem2::pointer(int minSize) {
	ensureMinSize(minSize);
	return mem;
} ///:~

