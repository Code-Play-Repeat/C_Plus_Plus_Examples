#include <iostream>
#include <stdlib.h>

using namespace std;

class Two{
public:
	void f1(int one, int two) {cout << one <<" " << two << endl;}
	void f2(int one, int ) {cout << one <<" " << one << endl;}
};

int main(int argc, char** argv)
{
int i = atoi(argv[1]);
int j = atoi(argv[2]);
Two in;
in.f1(i,j);
in.f2(i,j);
}
