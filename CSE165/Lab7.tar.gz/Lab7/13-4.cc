#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
using namespace std;

class Counted 
{
public:
	int id;
	static int count;
	Counted(): id(count++) 
	{
		cout << id <<" it is being created" <<  endl;
	}
	~Counted()
	{
		cout << id <<" it is being destoryed" << endl;	
	}		

};

int Counted::count = 1;

int main (int argc, char** argv)
{
	vector<Counted*> countVector;
	int n = atoi(argv[1]);

	for (int i = 1; i <= n; i++)
		countVector.push_back(new Counted());
	for(int k = 0; k < countVector.size(); k++)
		delete (Counted*)countVector[k];


}

