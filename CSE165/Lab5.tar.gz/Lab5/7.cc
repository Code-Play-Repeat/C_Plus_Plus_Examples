#include <iostream>
using namespace std;
int main () {
double array [10] = {1,2,3};

cout << "Size of 1th Array:" << sizeof(array) << endl;

for (int i = 0; i <= (sizeof(array)/sizeof(array[0])-1); i++)
	cout << array[i] << endl;

double aggArray[] = {1,2,3};

cout << "Size of 2rd Array:" << sizeof(aggArray) << endl;
for (int i = 0; i <= (sizeof(aggArray)/sizeof(aggArray[0])-1); i++)
	cout <<  aggArray[i] << endl;
}
