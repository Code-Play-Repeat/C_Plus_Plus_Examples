#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

class Simple {
     public:
     int im;
     Simple (int i){
     im = i;
     cout << "Construct "<<  im << endl;
     }
     ~Simple(){
      cout << "Destruct " << im << endl;
     }

};

int main (int argc, char** argv) {
int n = atoi(argv[1]);
for (int i = 1; i <= n; i++)
{
    Simple newSimple(i);
    //delete newSimple;
}
}
