#include <iostream>
#include <string>
#include <stack>
using namespace std;

int main () {
stack<string> container;

string strArr[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
int i = 0;
while (i <= (sizeof(strArr)/sizeof(strArr[0])-1)){
container.push(strArr[i]);
i++;
}

while (!(container.empty())){

cout << container.top() << endl;
container.pop();
}
}
