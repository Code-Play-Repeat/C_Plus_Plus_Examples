#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

class Simple {
     public:
     int im;
     Simple (int i){
     im = i;
     cout << "Construct "<<  im << endl;
     }
     ~Simple(){
     cout << "Destruct " << im << endl;
     }
     void print () {
     cout << im << endl;
     }

};

int main (int argc, char** argv) {
Simple acSimple[] = { Simple(1), Simple(2),  Simple(3),  Simple(4), Simple(5),  Simple(6),  Simple(7),  Simple(8),  Simple(9),  Simple(10)};
for (int i = 0; i <= (sizeof (acSimple) / sizeof(acSimple[0]) - 1 ); i++)
   (acSimple[i]).print();

/*for (int i = (sizeof (acSimple) / sizeof(acSimple[0]) - 1 ); i <= (sizeof (acSimple) / sizeof(acSimple[0]) - 1 ) ; i--)
  delete acSimple[i];*/

}
