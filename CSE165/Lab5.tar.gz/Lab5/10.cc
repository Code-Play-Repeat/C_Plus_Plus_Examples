#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

class Simple {
     public:
     int im;
     // Simple () { }; // for testing purposes only
     Simple (int i){
     im = i;
     cout << "Construct "<<  im << endl;
     }
     ~Simple(){
      cout << "Destruct" << endl;
     }

};

int main (int argc, char** argv) {
int n = atoi(argv[1]);
for (int i = 1; i <= n; i++)
{
    Simple woCSimple;
    Simple *wCSimple = new Simple (i);
    delete wCSimple;
}
}

// If there are no constructors for the class then the compiler uses the default constructor when creating
// the object of that class. If a constructor is defined, the compiler ends up being unsure of which constructor is being
// used to create an object of that class even though the default constructor is called in this case it isn't defined when there is another
// constructor (that can possibly take in an argument) is defined.
