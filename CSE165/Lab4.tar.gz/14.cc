#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "../require.h"


using namespace std;
//New Header File

class StackOfInt {
struct StackImp {
void* data;
StackImp* next;
void initialize(void* dat, StackImp* nxt);
}* head;
public:
void initialize();
void push(void* dat);
void* peek();
void* pop();
void cleanup();
};

//Stack.cpp
void StackOfInt::StackImp::initialize(void* dat, StackImp* nxt) {
data = dat;
next = nxt;
}
void StackOfInt::initialize() { head = 0; }

void StackOfInt::push(void* dat) {
StackImp* newStackImp = new StackImp;
newStackImp->initialize(dat, head);
head = newStackImp;
}
void* StackOfInt::peek() {
require(head != 0, "Stack empty");
return head->data;
}
void* StackOfInt::pop() {
if(head == 0) return 0;
void* result = head->data;
StackImp* oldHead = head;
head = head->next;
delete oldHead;
return result;
}
void StackOfInt::cleanup() {
require(head == 0, "Stack not empty");
} ///:~


//Testing Main function
int main(int argc, char* argv[]) {
StackOfInt intStack;
intStack.initialize();
int size = 0;
intStack.push(new string(argv[1]));
cout << *(string*)intStack.pop() << endl;
intStack.cleanup();
} ///:~

