#include <iostream>

using namespace std;

struct Hen {
public:
	string hen;
	void display() {cout << hen << endl;};	
	struct Nest;	
	friend struct Nest;
	struct Nest{
	string nest;
	public:
		void display() {cout << nest << endl;};
		struct Egg;		
		friend struct Egg;		
		struct Egg{
		string egg;
		public:		
			void display() {cout << egg << endl;};
		};
	};
};

int main() {
	Hen hen;
	hen.hen = "hen";
	Hen::Nest nest;
	nest.nest = "nest";
	Hen::Nest::Egg egg;
	egg.egg = "egg";
	hen.display();
	nest.display();
	egg.display();
}
