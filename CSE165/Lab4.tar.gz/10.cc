#include <iostream>
#include <cassert>
#include <fstream>
#include <vector>
#include <string>
#include <cstdlib>

using namespace std;

//: C05:Stash.h
// Converted to use access control
class Stash {
int size;
// Size of each space
int quantity; // Number of storage spaces
int next;
// Next empty space
// Dynamically allocated array of bytes:
unsigned char* storage;
void inflate(int increase);
public:
	class Hen {
		public:
			string hen;
			void print() {cout << hen << endl;};
		};
void initialize(int size);
void cleanup();
int add(const void* element);
void* fetch(int index);
int count();
};

//: C04:CppLib.cpp {O}
// C library converted to C++
// Declare structure and functions:

// Quantity of elements to add
// when increasing storage:
const int increment = 100;
void Stash::initialize(int sz) {
size = sz;
quantity = 0;
storage = 0;
next = 0;
}

int Stash::add(const void* element) {
if(next >= quantity) // Enough space left?
inflate(increment);
// Copy element into storage,
// starting at next empty space:
int startBytes = next * size;
unsigned char* e = (unsigned char*)element;
for(int i = 0; i < size; i++)
storage[startBytes + i] = e[i];
next++;
return(next - 1); // Index number
}
void* Stash::fetch(int index) {
// Check index boundaries:
assert(0 <= index);
if(index >= next)
return 0; // To indicate the end
// Produce pointer to desired element:
return &(storage[index * size]);
}
int Stash::count() {
return next; // Number of elements in CStash
}
void Stash::inflate(int increase) {
assert(increase > 0);
int newQuantity = quantity + increase;
int newBytes = newQuantity * size;
int oldBytes = quantity * size;
unsigned char* b = new unsigned char[newBytes];
for(int i = 0; i < oldBytes; i++)
b[i] = storage[i]; // Copy old to new
delete []storage; // Old storage
storage = b; // Point to new memory
quantity = newQuantity;
}
void Stash::cleanup() {
if(storage != 0) {
delete []storage;
}
} ///:~


//: C04:CppLibTest.cpp
//{L} CppLib
// Test of C++ library

int main(int argc, char** argv) {
Stash henStash;
Stash::Hen hen;
vector<string> v;
henStash.initialize(sizeof(string));
ifstream in(argv[1]);
string word;
while(in >> word)
v.push_back(word);
int max = atoi((v[0]).c_str());
for(int i = 1; i <= max; i++)
	henStash.add(&v[i]);
for(int j = 0; j < max; j++)
{
hen.hen = *(string*)henStash.fetch(j);
cout << hen.hen << endl;
}
henStash.cleanup();
} ///:~

