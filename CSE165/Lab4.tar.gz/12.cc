#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "../require.h"


using namespace std;
//New Header File

class Stack {
struct Link {
void* data;
Link* next;
void initialize(void* dat, Link* nxt);
}* head;
public:
class Hen {
		public:
			string hen;
			void print() {cout << hen << endl;};
		};
void initialize();
void push(void* dat);
void* peek();
void* pop();
void cleanup();
};

//Stack.cpp
void Stack::Link::initialize(void* dat, Link* nxt) {
data = dat;
next = nxt;
}
void Stack::initialize() { head = 0; }

void Stack::push(void* dat) {
Link* newLink = new Link;
newLink->initialize(dat, head);
head = newLink;
}
void* Stack::peek() {
require(head != 0, "Stack empty");
return head->data;
}
void* Stack::pop() {
if(head == 0) return 0;
void* result = head->data;
Link* oldHead = head;
head = head->next;
delete oldHead;
return result;
}
void Stack::cleanup() {
require(head == 0, "Stack not empty");
} ///:~


//Testing Main function
int main(int argc, char* argv[]) {
Stack henStack;
henStack.initialize();
int size = 0;
vector<string> v;
ifstream in(argv[1]);
string word;
while(in >> word)
{
henStack.push(new string(word));
size++;
}

string *s;
string st[size];
int i = size-1;
while((s = (string*)henStack.pop()) != 0)
{
st[i] = *s;
i--;
}

for (int i = 1; i < size; i++)
{
Stack::Hen hen;
hen.hen = st[i];
hen.print();
}

henStack.cleanup();
} ///:~

