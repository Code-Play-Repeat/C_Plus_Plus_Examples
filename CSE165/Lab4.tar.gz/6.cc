#include <iostream>

using namespace std;

class Hen {
public:
	void display() {cout << "hen" << endl;};
	class Nest{
	public:
	void display() {cout << "nest" << endl;};
		class Egg{
		public:		
		void display() {cout << "egg" << endl;};
		};
	};
};

int main() {
	Hen hen;
	Hen::Nest nest;
	Hen::Nest::Egg egg;
	hen.display();
	nest.display();
	egg.display();
}
