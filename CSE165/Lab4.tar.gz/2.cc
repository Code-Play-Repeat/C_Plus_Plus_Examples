#include <iostream>
#include <string>

using namespace std;

struct Lib {
private:
string s[3];
public:
void seta(string as){s[0] = as;};
void geta(){cout << s[0] << endl;};
void setb(string bs){s[1] = bs;};
void getb(){cout << s[1] << endl;};
void setc(string cs){s[2] = cs;};
void getc(){cout << s[2] << endl;};
};

int main() {
	Lib x;
	x.seta("a");
	x.setb("b");
	x.setc("c");
	x.geta();
	x.getb();
	x.getc();
}
