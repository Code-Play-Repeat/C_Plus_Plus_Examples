#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main (int argc, char** argv){

	int wordCount = 0;
	string word;
	ifstream in(argv[1]);
	while (in >> word ){
		wordCount++;
	}
	cout << wordCount << endl;
return 0;
}

