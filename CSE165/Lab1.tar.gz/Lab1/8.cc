#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

int main(int argc, char** argv){
	vector<float> f;
	ifstream in (argv[1]);
	float numbers;

	while (in >> numbers)
	     f.push_back(numbers);

	for (int i = 0; i < f.size(); i++)
		cout << f[i] <<" ";
}	
