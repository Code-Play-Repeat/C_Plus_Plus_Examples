#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int main(int argc, char** argv){
	vector<string> v;
	ifstream in(argv[1]);
	string line = "\n";
	while (getline (in, line)) {
	cout << line;
	cin.get();
	
	}
}
