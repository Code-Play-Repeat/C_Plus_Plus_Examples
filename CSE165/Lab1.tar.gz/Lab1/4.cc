#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main (int argc, char** argv) {
	ifstream in (argv[1]);
	int countWord = 0;
	string word;
	while (in >> word){
		if (word == argv[2])
		   countWord ++;
	}
	cout << countWord<< endl;
return 0;
}
