#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

int main(int argc, char** argv){
	vector<float> f1, f2, f3;
	ifstream in1 (argv[1]);
	float nums = 0;
	while (in1 >> nums)
		f1.push_back(nums);
	for (int i = 0; i < f1.size(); i++)
		f2.push_back(f1[i] + 5);
	
	for (int i = 0; i < f1.size(); i++)
		cout << f1[i] << " "; 
	cout << endl;

	for (int i = 0; i < f2.size(); i++)
		cout << f2[i] << " ";
	cout << endl;

	for (int i = 0; i < f1.size(); i++) {
		f3.push_back (f1[i] + f2[i]);
		cout << f3[i] << " ";
	}
	cout << endl;
}	
