#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

int main(int argc, char** argv){
	vector<float> f;
	ifstream in (argv[1]);
	float nums;
	while (in >> nums)
	     f.push_back(nums);

	for (int i = 0; i < f.size(); i++)
		cout << f[i] << " ";
	
	cout << endl;

	for (int i = 0; i < f.size(); i++){
		f[i] = f[i] * f[i];
		cout << f[i] << " ";  
	}
	
	cout << endl;
}	
