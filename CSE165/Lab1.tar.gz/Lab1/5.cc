    //: C02:Fillvector.cpp
    // Copy an entire file into a vector of string
    #include <string>
    #include <iostream>
    #include <fstream>
    #include <vector>
    using namespace std;

    int main(int argc, char **argv) {
      vector<string> v;
      ifstream in(argv[1]);
      string line;
      while(getline(in, line))
        v.push_back(line); // Add the line to the end
      // Add line numbers:
      int j = 0;
      for(int i = v.size()-1; i >= 0; i--)
	{
        	cout << j << ": "<< v[i] << endl;
		j++;
	}

return 0;
    } ///:~
