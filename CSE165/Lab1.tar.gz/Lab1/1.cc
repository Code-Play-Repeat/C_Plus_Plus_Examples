#include <iostream>

using namespace std;

int main() {
	cout << "Hello, World! " << "\n"
	     << "My name is Kevin." << "\n"
	     << "I am 20. " << endl;
return 0;
}
