#define _USE_MATH_DEFINES
#include <iostream>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main (int argc, char **argv) {
	double PI = 3.14;
	int rad = atoi(argv[1]);
	double area = PI * rad * rad;
	cout << area << endl;
return 0;
}
