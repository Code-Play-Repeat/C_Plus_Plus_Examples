#include "TPStash2.h"
#include "require.h"
#include <iostream>
#include <vector>
#include <string>
using namespace std;

template <class V>
class Int {
	V i;
public:
	Int(int ii) {i = ii; cout << ">" << i << ' '; }
	~Int() { cout << "~" << i << ' '; }
	operator V() const { return i; }
	friend ostream& operator<<(ostream& os, const Int& x) {
		return os << "Int: " << x.i;
	}
	friend ostream& operator<<(ostream& os, const Int* x) {
		return os << "Int: " << x->i;
	}
};

int main() {
	{ // To force destructor call
		PStash< Int<double> > ints;
		for(double i = 0; i < 30; i++)
			ints.add(new Int<double>(i));
		cout << endl;
		PStash<Int<double> >::iterator it = ints.begin();
		it += 5;
		PStash<Int<double> >::iterator it2 = it + 10;
		for(; it != it2; it++)
			delete it.remove(); // Default removal
		cout << endl;
		for(it = ints.begin();it != ints.end();it++)
			if(*it) // Remove() causes "holes"
				cout << *it << endl;
	} // "ints" destructor called here
	cout << "\n-------------------\n";
	ifstream in("16-17.cc");
	assure(in, "16-17.cc");
	// Instantiate for String:
	PStash<string> strings;
	string line;
	while(getline(in, line))
		strings.add(new string(line));
	PStash<string>::iterator sit = strings.begin();
	for(; sit != strings.end(); sit++)
		cout << **sit << endl;
	sit = strings.begin();
	int n = 26;
	sit += n;
	for(; sit != strings.end(); sit++)
		cout << n++ << ": " << **sit << endl;
} ///:~

