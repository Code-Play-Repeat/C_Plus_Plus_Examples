#include <iostream>
#include <vector>
using namespace std;

template<class T> class Stack {
	struct Link {
		T* data;
		Link* next;
		Link(T* dat, Link* nxt)
		: data(dat), next(nxt) {}
	}* head;
	bool own;
public:
	Stack(bool own = true) : head(0), own(own) {}
	~Stack();
	void push_back(T* dat) {
		head = new Link(dat,head);
	}
	T* peek() const {
		return head ? head->data : 0;
	}
	T* pop_back();
	bool owns() const { return own; }
	void owns(bool newownership) {
		own = newownership;
	}
	// Auto-type conversion: true if not empty:
	operator bool() const { return head != 0; }
};
template<class T> T* Stack<T>::pop_back() {
	if(head == 0) return 0;
	T* result = head->data;
	Link* oldHead = head;
	head = head->next;
	delete oldHead;
	return result;
}
template<class T> Stack<T>::~Stack() {
	if(!own) return;
	while(head)
		delete pop_back();
}

class Simple {};

int main() {
	Stack<Simple> st;
	st.push_back(new Simple);
	st.push_back(new Simple);
	st.push_back(new Simple);
	st.pop_back();
	st.pop_back();

	// No destruction necessary since
	// ac "owns" all the objects
} ///:~

