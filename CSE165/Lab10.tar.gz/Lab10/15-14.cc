//: C15:AddingVirtuals.cc
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
// Adding virtuals in derivation
#include <iostream>
#include <string>
#include <typeinfo>

using namespace std;

class Pet {
  string pname;
public:
  Pet(const string& petName) : pname(petName) {}
  virtual string name() const = 0;
  virtual string speak() const = 0;
};
string Pet::name() const { return pname; }

class Dog : public Pet {
  string dname;
public:
  Dog(const string& petName) : Pet(petName) { dname = petName;}
  // New virtual function in the Dog class:
  virtual string name () const {return Pet::name();}
  virtual string sit() const {
    return Pet::name() + " sits";
  }

  string speak() const {// Override
      return Pet::name() + " says 'Bark!'";
  }
};

int main() {
  Pet* p[] = {new Dog("generic"),new Dog("bob")}; // Had to change new Pet ("generic") to new Dog ("generic"). The reason is can't create an object of Pet because it is now a pure abstract class.
  cout << "p[0]->speak() = "
       << p[0]->speak() << endl;
  cout << "p[1]->speak() = "
       << p[1]->speak() << endl;
//! cout << "p[1]->sit() = "
//!      << p[1]->sit() << endl; // Illegal
} ///:~
