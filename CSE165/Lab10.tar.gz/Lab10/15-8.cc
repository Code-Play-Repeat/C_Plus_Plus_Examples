#include <iostream>
#include <vector>
using namespace std;

class Rodent {
public:
virtual void dig () {cout  << "Rodent digging\n";} // Without virtual these functions are called instead of appropiately calling the derived class functions.
virtual void eat () {cout  << "Rodent eating\n";}
};

class Mouse : public Rodent {
public:
void dig () {cout << "Mouse digging in wall\n";}
void eat () {cout << "Mouse eating cheese\n";}
};
class Gerbil : public Rodent {
public:
void dig () {cout << "Gerbil digging in sand\n";}
void eat () {cout << "Gerbil eating grain\n";}
};
class Hamster : public Rodent {
public:
void dig () {cout << "Hamster digging in bedding\n";}
void eat () {cout << "Hamster eating pellets\n";}
};

class BlueHamster: public Hamster {
public:
void dig () {cout << "Blue Hamster digging in bedding\n";}
void eat () {cout << "Blue Hamster eating pellets\n";}
};

int main (){
Rodent* rod;
rod = new BlueHamster(); 
  rod->dig(); // base methods do not need to be changed in order to accomodate Blue Hamster type.
	rod->eat(); //

return 0;
}
