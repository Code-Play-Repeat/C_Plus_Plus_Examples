#include <iostream>
#include <vector>
#include "require.h"
using namespace std;

template<class T, int ssize = 100>
class Stack {
	// Default constructor performs object
	// initialization for each element in array:
	vector<T> v;
	int top;
public:
	Stack() : top(0) {}
	// Copy-constructor copies object into array:
	void push(const T& x) {
		require(top < ssize, "Too many push()es");
		v.push_back(x);
		top++;
	}
	T peek() const { return v.front(); }
	// Object still exists when you pop it;
	// it just isn't available anymore:
	T pop() {
		require(top > 0, "Too many pop()s");
		--top;
		T obj = v.back();
		v.pop_back();
		return obj;
	}
};


class SelfCounter {
	static int counter;
	int id;
public:
	SelfCounter() : id(counter++) {
		cout << "Created: " << id << endl;
	}
	SelfCounter(const SelfCounter& rv) : id(rv.id){
		cout << "Copied: " << id << endl;
	}
	SelfCounter operator=(const SelfCounter& rv) {
		cout << "Assigned " << rv.id << " to "
				<< id << endl;
		return *this;
	}
	~SelfCounter() {
		cout << "Destroyed: "<< id << endl;
	}
	friend std::ostream& operator<<(
			ostream& os, const SelfCounter& sc){
		return os << "SelfCounter: " << sc.id;
	}
};

int SelfCounter::counter = 0;

#include <iostream>
using namespace std;
int main() {
	Stack<SelfCounter> sc;
	for(int i = 0; i < 10; i++)
		sc.push(SelfCounter());
	// OK to peek(), result is a temporary:
	sc.peek();
	for(int k = 0; k < 10; k++)
		sc.pop();
}


