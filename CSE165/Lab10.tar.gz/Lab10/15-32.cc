#include <iostream>
using namespace std;

class Base
{
public:
    virtual void function1() {};
};

class Base2
{
public:
    virtual void function2() {};
};
 
class D1: public Base, public Base2
{
public:
};
 

int main() {
Base base1;
Base base2;
D1 d1;
cout << sizeof(base1) << endl; // size return: 8
cout << sizeof(base2) << endl; // size return: 8
cout << sizeof(d1) << endl; // size return: 16 got two VPTR's in the derived class.
}
