
#include <iostream>
using namespace std;

class Base {
public:
  virtual ~Base() { cout << "~Base()\n"; f(); }
  virtual void f() { cout << "Base::f()\n"; }
};

class Derived : public Base {
public:
  ~Derived() { cout << "~Derived()\n"; f(); }
  void f() { cout << "Derived::f()\n"; }
};

class Derived2 : public Derived {
  ~Derived2() { cout << "~Derived2()\n"; f(); }
  void f() { cout << "Derived2::f()\n"; }
};

int main() {
  Base* bp = new Derived; // Upcast
  delete bp;
  Base* bp2 = new Derived2;
  delete bp2;
} ///:~

/* 
output:

~Derived()  
Derived::f() // When in the derived destructor the f() from derived gets called.
~Base()
Base::f() // when in the base destructor the f() from base gets called
~Derived2()
Derived2::f() // when in the derived 2 destructor the f() from derived2 gets called.
~Derived()
Derived::f()
~Base()
Base::f()
 
When calling virtual functions in destructors or constructors only the local function is called even though the function is techincally overidden in the following derived classes.
*/
