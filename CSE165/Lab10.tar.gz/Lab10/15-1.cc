#include <iostream>
using namespace std;

class Shape {
public:

virtual void draw () { cout << "Shape::draw()\n";}
	
};

class Circle : public Shape {
public:
void draw () { cout << "Circle::draw()\n";}
};

class Square : public Shape {
public:
void draw () { cout << "Square::draw()\n";}
};

class Triangle: public Shape {
public:
void draw() { cout << "Triangle::draw()\n";}
};

int main (){

Shape* shape[] = { new Circle, new Square, new Triangle};
int arsize = sizeof(shape)/ sizeof(shape[0]);

for (int i = 0; i < arsize; i++)
{
	shape[i]->draw();
	delete shape[i];
}

return 0;
}
