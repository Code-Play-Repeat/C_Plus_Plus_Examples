#include <iostream>
#include "require.h"
using namespace std;

template<class T, int ssize = 100>
class Stack {
	// Default constructor performs object
	// initialization for each element in array:
	T stack[ssize];
	int top;
	int* size;
public:
	Stack() : top(0) {*size = ssize;}
	// Copy-constructor copies object into array:
	void push(const T& x) {
		require(top < *size, "Too many push()es");
		stack[top++] = x;
		*size += 1;
	}
	T peek() const { return stack[top]; }
	// Object still exists when you pop it;
	// it just isn't available anymore:
	T pop() {
		require(top > 0, "Too many pop()s");
		return stack[--top];
	}
};


class SelfCounter {
	static int counter;
	int id;
public:
	SelfCounter() : id(counter++) {
		cout << "Created: " << id << endl;
	}
	SelfCounter(const SelfCounter& rv) : id(rv.id){
		cout << "Copied: " << id << endl;
	}
	SelfCounter operator=(const SelfCounter& rv) {
		cout << "Assigned " << rv.id << " to "
				<< id << endl;
		return *this;
	}
	~SelfCounter() {
		cout << "Destroyed: "<< id << endl;
	}
	friend std::ostream& operator<<(
			ostream& os, const SelfCounter& sc){
		return os << "SelfCounter: " << sc.id;
	}
};

int SelfCounter::counter = 0;

#include <iostream>
using namespace std;
int main() {
	Stack<SelfCounter> sc;
	for(int i = 0; i < 10; i++)
		sc.push(SelfCounter());
	// OK to peek(), result is a temporary:
	cout << sc.peek() << endl;
	for(int k = 0; k < 10; k++)
		cout << sc.pop() << endl;
}


