#include <iostream>
using namespace std;

class Shape {
public:
Shape(){/*draw();*/} // gives warning of draw being abstract because it is a pure virtual function.
virtual void draw () = 0 ;// { cout << "Shape::draw()\n"; } // can't define it here because inline pure virtual functions are illegal;
	
};
void Shape::draw(){ cout <<"Shape::draw()\n";} // must define here

class Circle : public Shape {
public:
void draw () {Shape::draw(); cout << "Circle::draw()\n";} // must be called within derived classes because a pure abstract object of type Shape cannot be created
};

class Square : public Shape {
public:
void draw () {Shape::draw(); cout << "Square::draw()\n";} 
};

class Triangle: public Shape {
public:
void draw() { Shape::draw(); cout << "Triangle::draw()\n";} 
};

/*void upcast (Shape obj) { // Compiler complains that obj is an abstract type shape and thus it will not allocate an object of abstract type.
obj.draw();
}*/
void upcast (Shape& obj) { // This is ok because the compiler will take a reference of type shape as long as the reference passed isn't to an abstract object from an abstract class.
obj.draw();
}

int main (){
Circle circle;
Square square;
Triangle triangle;


upcast(circle);
upcast (square);
upcast(triangle);

return 0;
}
