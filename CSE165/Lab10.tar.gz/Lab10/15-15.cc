#include <iostream>
using namespace std;

class base{
public:
	base() { f();} // calling f();
	virtual void f(){cout <<"Base::f()\n";}
};

class derived : public base
{
public:
	void f() {cout << "Derived::f()\n";}
	void g() {f();}
};

int main()
{
	derived test; // The virtual function f() retains its previous definition even though an object of type test has been created. This is interesting since techincally f() is a virtual function that is supposed to be overidden in derived.
	test.f(); // Calling withing the function produces the overidden function.
}
