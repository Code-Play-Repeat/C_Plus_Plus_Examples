#include <iostream>
using namespace std;

class Overload {
public:
	 virtual void f() { cout << "Overload::f()" << endl; }
  virtual void f(int i) { cout << "Overload::f(int)" << endl; }
	virtual void f(double d) {cout << "Overload::f(double)" << endl;}
	
};
class Derived : public Overload {
public:
	// void f(int i) { cout << "Derived::f(int) " << endl;}
};
int main ()
{
	Derived obj;
	Overload obj2; 
	//obj.f(); // Cannot call base class functions from the derived class object in this.
	obj.f(1); // Only the function Derived::f(int) gets called in this case. If it is not defined then Overload::f(int) and Overload::f(double) are called instead.
	obj.f(2.0);
	
	Overload* pObj = &obj;
	// To call all of the base functions the overidden function in derived must be removed.
	pObj->f();// After the overriden function is gone all base functions can be called.
	pObj->f(1);
	pObj->f(2.0);
}
