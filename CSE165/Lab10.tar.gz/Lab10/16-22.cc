#include <iostream>
#include <vector>
#include <string>
using namespace std;

class StringVector {
	 vector<void*> v;
public:
	void push_back(string* ss) {v.push_back(ss);}
	string* operator[] (int s) 
	{
		return v[s];
	}
};

int main (){
return 0;
}



