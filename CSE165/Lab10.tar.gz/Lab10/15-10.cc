#include <iostream>
#include <vector>
using namespace std;

class Rodent {
public:
virtual void dig () = 0;
virtual void eat () = 0;
virtual ~Rodent () = 0;
};
Rodent::~Rodent () {cout << "Rodent destructor\n";}

class Mouse : public Rodent {
public:
void dig () {cout << "Mouse digging in wall\n";}
void eat () {cout << "Mouse eating cheese\n";}
~Mouse () {cout << "Mouse destructor\n";}
};
class Gerbil : public Rodent {
public:
void dig () {cout << "Gerbil digging in sand\n";}
void eat () {cout << "Gerbil eating grain\n";}
~Gerbil () {cout << "Gerbil destructor\n";}
};
class Hamster : public Rodent {
public:
void dig () {cout << "Hamster digging in bedding\n";}
void eat () {cout << "Hamster eating pellets\n";}
~Hamster () {cout << "Hamster destructor\n";}
};

class BlueHamster: public Hamster {
public:
void dig () {cout << "Blue Hamster digging in bedding\n";}
void eat () {cout << "Blue Hamster eating pellets\n";}
~BlueHamster() {cout << "Blue Hamster destructor\n";}
};

int main (){
Rodent* rod = new Hamster(); 
delete rod; // with non Virtual destructor the only destructor that gets called is the Rodent's.

return 0;
}
