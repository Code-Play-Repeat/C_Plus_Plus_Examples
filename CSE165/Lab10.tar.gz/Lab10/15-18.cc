#include <iostream>
using namespace std;

class base {
public:
	string member;
};

class derived : public base {
public:
	string newMember;
};

void size (base obj) { cout << sizeof(obj) << endl; }

int main ()
{
	derived obj;
	cout << sizeof(obj) << endl;
	size(obj);
}
/*
output:

16 // The Derived object is bigger because it has to contain both the size of base's member and its own newMember.
8 // Base object is smaller because it only has one data member.
*/
