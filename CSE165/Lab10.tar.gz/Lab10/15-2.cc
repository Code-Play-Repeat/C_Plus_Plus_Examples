#include <iostream>
using namespace std;

class Shape {
public:
Shape(){/*draw();*/} // gives warning of draw being abstract because it is a pure virtual function.
virtual void draw () = 0 ;// { cout << "Shape::draw()\n"; } // can't define it here because inline pure virtual functions are illegal;
	
};
void Shape::draw(){ cout <<"Shape::draw()\n";} // must define here

class Circle : public Shape {
public:
void draw () {Shape::draw(); cout << "Circle::draw()\n";}  // must be called within derived classes because a pure abstract object of type Shape cannot be created
};

class Square : public Shape {
public:
void draw () {Shape::draw(); cout << "Square::draw()\n";} 
};

class Triangle: public Shape {
public:
void draw() { Shape::draw(); cout << "Triangle::draw()\n";} 
};

int main (){

Shape* shape = new Circle();
Shape* shape2 = new Square();
Shape* shape3 = new Triangle();
// shape = new Shape(); // can't create an object of a class with at least one pure virtual function because it is abstract.
shape->draw();
shape2->draw();
shape3->draw();

return 0;
}
