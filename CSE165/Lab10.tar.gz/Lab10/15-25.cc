#include <iostream>
using namespace std;

class base {
public:
virtual	base* clone (base b) {cout <<"Cloning Base...\n"; base c = b; base *ptr = &c; return ptr;}
};

class derived : public base{
public:
	derived* clone (derived d) {cout <<"Cloning Derived...\n"; derived c = d; derived *ptr = &c; return ptr;}
};

class derived2 : public base {
public:
	derived2* clone (derived2 d) {cout <<"Cloning Derived2...\n"; derived2 c = d; derived2 *ptr = &c; return ptr;}
};
int main()
{
derived obj;
derived2 obj2;
base* obj3 = &obj;
base* obj4 = &obj2;
obj.clone(obj);
obj2.clone(obj2);
obj3->clone(obj);
obj4->clone(obj2);
return 0;
}
