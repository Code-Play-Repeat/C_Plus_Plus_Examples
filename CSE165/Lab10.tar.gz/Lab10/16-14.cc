#include "require.h"
#include <iostream>
#include <vector>
#include <string>
#include <cstring>

using namespace std;
template<class T, int incr = 20>
class PStash {
	int quantity;
	int next;
	vector<T*> storage;
	void inflate(int increase = incr);
public:
	PStash() : quantity(0), next(0) {}
	~PStash();
	int add(T* element);
	T* operator[](int index) const;
	T* remove(int index);
	int count() const { return next; }
	// Nested iterator class:
	class iterator; // Declaration required
	friend class iterator; // Make it a friend
	class iterator { // Now define it
		PStash& ps;
		int index;
	public:
		iterator(PStash& pStash)
		: ps(pStash), index(0) {}
		// To create the end sentinel:
		iterator(PStash& pStash, bool)
		: ps(pStash), index(ps.next) {}
		// Copy-constructor:
		iterator(const iterator& rv)
		: ps(rv.ps), index(rv.index) {}
		iterator& operator=(const iterator& rv) {
			ps = rv.ps;
			index = rv.index;
			return *this;

		}
		iterator& operator++() {
			require(++index <= ps.next,
					"PStash::iterator::operator++ "
					"moves index out of bounds");
			return *this;
		}
		iterator& operator++(int) {
			return operator++();
		}
		iterator& operator--() {
			require(--index >= 0,
					"PStash::iterator::operator-- "
					"moves index out of bounds");
			return *this;
		}
		iterator& operator--(int) {
			return operator--();
		}
		// Jump interator forward or backward:
		iterator& operator+=(int amount) {
			require(index + amount < ps.next &&
					index + amount >= 0,
					"PStash::iterator::operator+= "
					"attempt to index out of bounds");
			index += amount;
			return *this;
		}
		iterator& operator-=(int amount) {
			require(index - amount < ps.next &&
					index - amount >= 0,
					"PStash::iterator::operator-= "
					"attempt to index out of bounds");
			index -= amount;
			return *this;
		}
		// Create a new iterator that's moved forward
		iterator operator+(int amount) const {
			iterator ret(*this);
			ret += amount; // op+= does bounds check
			return ret;
		}
		T* current() const {
			return ps.storage[index];
		}

		T* operator*() const { return current(); }
		T* operator->() const {
			require(ps.storage.back() != 0,
					"PStash::iterator::operator->returns 0");
			return current();
		}
		// Remove the current element:
		T* remove(){
			return ps.remove(index);
		}
		// Comparison tests for end:
		bool operator==(const iterator& rv) const {
			return index == rv.index;
		}
		bool operator!=(const iterator& rv) const {
			return index != rv.index;
		}
	};
	iterator begin() { return iterator(*this); }
	iterator end() { return iterator(*this, true);}
};
// Destruction of contained objects:
template<class T, int incr>
PStash<T, incr>::~PStash() {
	for(int i = 0; i < next; i++)
		storage.pop_back();

}
template<class T, int incr>
int PStash<T, incr>::add(T* element) {
	if(next >= quantity)
	{
		storage.push_back(element);
		next++;
	}
	return(next - 1); // Index number
}
template<class T, int incr> inline
T* PStash<T, incr>::operator[](int index) const {
	require(index >= 0,
			"PStash::operator[] index negative");
	if(index >= next)

		return 0; // To indicate the end
	require(storage.back()!= 0,
			"PStash::operator[] returned null pointer");
	return storage.back();
}
template<class T, int incr>
T* PStash<T, incr>::remove(int index) {
	// operator[] performs validity checks:
	T* v = operator[](index);
	return v;
}
template<class T, int incr>
void PStash<T, incr>::inflate(int increase) {
	const int tsz = sizeof(T*);
	T** st = new T*[quantity + increase];
	memset(st, 0, (quantity + increase) * tsz);
	memcpy(st, storage, quantity * tsz);
	quantity += increase;
}

class Int {
	int i;
public:
	Int(int ii = 0) : i(ii) {
		cout << ">" << i << ' ';
	}
	~Int() { cout << "~" << i << ' '; }
	operator int() const { return i; }
	friend ostream&
	operator<<(ostream& os, const Int& x) {
		return os << "Int: " << x.i;
	}
	friend ostream&
	operator<<(ostream& os, const Int* x) {
		return os << "Int: " << x->i;
	}
};
int main() {
	{ // To force destructor call
		PStash<Int> ints;
		for(int i = 0; i < 30; i++)
			ints.add(new Int(i));
		cout << endl;
		PStash<Int>::iterator it = ints.begin();
		it += 5;
		PStash<Int>::iterator it2 = it + 10;
		cout << endl;
		for(it = ints.begin();it != ints.end();it++)
			if(*it) // Remove() causes "holes"
				cout << *it << endl;
	} // "ints" destructor called here
	cout << "\n-------------------\n";
	ifstream in("16-14.cc");
	assure(in, "16-14.cc");
	// Instantiate for String:
	PStash<string> strings;
	string line;
	while(getline(in, line))
		strings.add(new string(line));
	PStash<string>::iterator sit = strings.begin();
	for(; sit != strings.end(); sit++)
		cout << **sit << endl;
	sit = strings.begin();
	int n = 26;
	sit += n;
	for(; sit != strings.end(); sit++)
		cout << n++ << ": " << **sit << endl;
} ///:~

