#include "require.h"
#include <iostream>
using namespace std;

template<class T>
T fibonacci(T n) {
	const int sz = 100;
	require(n < sz);
	static T f[sz]; // Initialized to zero
	f[0] = f[1] = 1;
	// Scan for unfilled array elements:
	int i;
	for(i = 0; i < sz; i++)
		if(f[i] == 0) 
			break;
	while(i <= n) {
		f[i] = f[i-1] + f[i-2];
		i++;
	}
	return f[n];
} ///:~

int main() {
	int i = 5;
	double d = fibonacci(i);
	i = 4;
	float f = fibonacci(i);
	i = 3;
	long l = fibonacci(i);
	i = 2;
	short s = fibonacci(i);
	cout << d << endl;
	cout << f << endl;
	cout << l << endl;
	cout << s << endl;
}
