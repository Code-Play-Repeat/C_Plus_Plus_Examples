//: C15:Early.cc
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
// Early binding & virtual functions
#include <iostream>
#include <string>
using namespace std;

class Pet {
public:
  virtual string speak() const = 0;
};
string Pet::speak() const { return " ";}

class Dog : public Pet {
public:
  string speak() const { Pet::speak(); return "Bark!"; }
};

int main() {
  Dog ralph;
  Pet* p1 = &ralph;
  Pet& p2 = ralph;
  Pet* p3 = p1;
  // Late binding for both:
  cout << "p1->speak() = " << p1->speak() <<endl;
  cout << "p2.speak() = " << p2.speak() << endl;
  cout << "p3->speak() = " << p3->speak() << endl; // ------> Can't early bind to an abstract object because it cannot be created.
} ///:~
