#include <iostream>
#include <vector>
#include <set>
using namespace std;

template <class T>
class Simple {
public:
	set<T> s;
	void add(T ap) {s.insert(ap);}

};

int main() {
	Simple<int> simple;
	simple.add(1);
	simple.add(2);
	simple.add(3);
	simple.add(4);
	simple.add(5);
	set<int>::iterator it;
	for ( it = simple.s.begin(); it != simple.s.end(); it++ )
		cout << " " << *it;
	cout << endl;
}
