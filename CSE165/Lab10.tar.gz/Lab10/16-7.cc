#include "require.h"
#include <iostream>
#include <set> // Standard C++ Library container
#include <string>
using namespace std;

template <class T>
class AutoCounter {
	static int count;
	int id;
public:
	class CleanupCheck {
		std::set<T*> trace;
	public:
		void add(T* ap) {
			trace.insert(ap);
		}
		void remove(T* ap) {
			require(trace.erase(ap) == 1,
					"Attempt to delete AutoCounter twice");
		}
		~CleanupCheck() {
			std::cout << "~CleanupCheck()"<< std::endl;
			require(trace.size() == 0,
					"All AutoCounter objects not cleaned up");
		}
	};

	static CleanupCheck verifier;
	AutoCounter() : id(count++) {
		verifier.add(this); // Register itself
		std::cout << "created[" << id << "]"
				<< std::endl;
	}
	// Prevent assignment and copy-construction:
	AutoCounter(const AutoCounter&);
	void operator=(const AutoCounter&);
public:
	// You can only create objects with this:
	static AutoCounter* create() {
		return new AutoCounter();
	}
	~AutoCounter() {
		std::cout << "destroying[" << id  
				<< "]" << std::endl;
		verifier.remove(this);
	}
	// Print both objects and pointers:
	friend std::ostream& operator<<(
			std::ostream& os, const AutoCounter& ac){
		return os << "AutoCounter " << ac.id;
	}
	friend std::ostream& operator<<(
			std::ostream& os, const AutoCounter* ac){
		return os << "AutoCounter " << ac->id;
	}

};

class Simple {
public:
	string s;
};

int main() {
	Simple* simple;
	AutoCounter<Simple>::CleanupCheck cc;
	simple->s = "simple";
	cc.add(simple);
	cc.remove(simple);
}

