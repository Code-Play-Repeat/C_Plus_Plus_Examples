#include <iostream>
#include <vector>
using namespace std;

class Rodent {
public:
virtual void dig () {cout  << "Rodent digging\n";} // Without virtual these functions are called instead of appropiately calling the derived class functions.
virtual void eat () {cout  << "Rodent eating\n";}
};

class Mouse : public Rodent {
public:
void dig () {cout << "Mouse digging in wall\n";}
void eat () {cout << "Mouse eating cheese\n";}
};
class Gerbil : public Rodent {
public:
void dig () {cout << "Gerbil digging in sand\n";}
void eat () {cout << "Gerbil eating grain\n";}
};
class Hamster : public Rodent {
public:
void dig () {cout << "Hamster digging in bedding\n";}
void eat () {cout << "Hamster eating pellets\n";}
};

int main (){
vector<Rodent*> rvector;

rvector.push_back(new Mouse());
rvector.push_back(new Gerbil());
rvector.push_back(new Hamster());

for (int i = 0; i < rvector.size(); i++)
{
	rvector[i]->dig();
	rvector[i]->eat();
}

return 0;
}
