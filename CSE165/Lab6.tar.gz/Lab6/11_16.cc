#include <iostream>
using namespace std;

class X {
public:
   X() { cout <<"Default constructor" << endl;}
   X(const X& x){cout << "Copy constructor" << endl;}
   void f1(X x){}
   X f2(X x) { return x; // where the second copy of x in this function is made.}
};

int main () {
X x;
X copy = x; // copy of the object x is made so the copy constructor is called
copy.f1(x); /* The object of x is passed by value and thus a copy of the object x is passed
	    to the function and the copy constructor is called. */
copy.f2(x); /* A copy of the object x is passed to the function and then another copy of the object 
	       is returned by the function. This function thus creates 2 copies of x when called and calls the copy
	       constructor twice.*/
}   
