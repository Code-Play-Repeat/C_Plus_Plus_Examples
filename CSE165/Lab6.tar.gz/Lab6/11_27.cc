//: C03:FunctionTable.cpp
// Using an array of pointers to functions
#include <iostream>
#include <vector>
using namespace std;
// A macro to define dummy functions:
#define DF(N) void N() { cout << "function " #N " called..." << endl; }

DF(a); DF(b); DF(c); DF(d); DF(e); DF(f); DF(g);

void (*func_table[])() = { a, b, c, d, e, f, g };
typedef void (*fptr) ();

class functionTable
{ 
public:
vector <fptr> ft;
void add(void (*fptr)()) {ft.push_back(fptr);}
void remove() {ft.pop_back();}
void run() {
 for (int i = 0; i < ft.size(); i++){
  add(func_table[i]);
  (*ft[i])();
  }
 }
};
int main () {
functionTable ftab;
ftab.run();

}


