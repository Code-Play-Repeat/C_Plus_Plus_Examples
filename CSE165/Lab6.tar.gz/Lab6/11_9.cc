#include <iostream>
using namespace std;
class X {

 void mf() const { cout << "const member function" << endl;}
 void f() {cout << "non constant member function" << endl;}
 public:
/* Passed by value so a copy of the object is passed to this function. Since only the function
   is supposed to be constant it doesn't matter whether the object is not constant or not. We can
   still call the constant function.
   */
 void f1(X x1){ 
  x1.mf(); 
  x1.f();
 }
/* Passed by reference so the actual object is accessed in this function. The function is still the only
  constant of the class and even though the object is directly accessed the constant function remains the same.*/
 void f2(X& x2){
  x2.mf();
  x2.f();
 }
/* Passed by constant reference. The compiler doesn't accept the constant reference here because this function could possibly
   modify the argument and this violates the constancy of the object argument.*/
 void f3(const X& x3){
  x3.mf();
  x3.f();
 } 
};



