#include <iostream>
using namespace std;

class X {
public:
   X() { cout <<"Default constructor" << endl;} // Default constructor only gets called when the class is created through regular instantiation
   void print() {cout <<"Contents" << endl;}
};

int main (){
X x;
x.print();

cout << "Calling default copy constructor" << endl;
/* Default copy constructor gets called instead of the default constructor and thus the "Default constructor" message is never printed.*/
X copy = x; 
copy.print();
}
