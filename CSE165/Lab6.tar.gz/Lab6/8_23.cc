#include <iostream>
using namespace std;
class cmfclass{
public:
void cfunction() const { cout << "const" << endl;}
void function(){cout << "non-const" << endl;}
};
int main (){
const cmfclass cobj();
cmfclass ncobj;
cobj.function();
ncobj.cfunction();
ncobj.function();
}
/* When creating const objects, the data members and functions have to be constant otherwise
   the compiler has no way of checking for the constantness of the object. It is ok for a non-constant object to
   call a constant function or a non-constant function because only the function is constant but not the entire object. */
