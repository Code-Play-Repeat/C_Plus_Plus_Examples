#include <iostream>
using namespace std;

int main () {
int &ir; /* References must be initialized upon declaration otherwise the reference could possibly point to any piece of storage
          especially a non-legitimate piece.*/
int i = 0;
int &cr = i;
int j = 0;
&cr = j;  /*References can't be redefined after initialization because they are tied to the piece of storage they were initialized with.*/
int &null = NULL; /* References can't point to null because references need to be pointed to a legitimate piece of storage and NULL could 
point to anything. */
 
}
