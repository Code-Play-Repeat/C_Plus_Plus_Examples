#include <iostream>
using namespace std;

class X {
public:
   X() { cout << "Default Constructor" << endl;}
   X(const X&) { 
    cout << "Copy Constructor" << endl;
    }

};

class Y {
public:
   X x;

};

int main () {
Y y1;
Y y2 = y1; // Copy constructor from X gets called instead of default copy constructor.
           // The synthesized copy constructor comes from X because Y contains an object member from X.
            
}
