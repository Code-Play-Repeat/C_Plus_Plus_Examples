#include <iostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

using namespace std;
class cclass {
const float cfl;
float fl;
public:
  cclass (const float cf, float f);
};

cclass::cclass (const float cf, float f): cfl(cf), fl(f){ 
 cout << cf << " " << f << endl;
}

int main (int argc, char** argv){

cclass ncclass(atof(argv[1]), atof(argv[2]));

}
