#include <iostream>
using namespace std;
class cmfclass{
public:
void cfunction() const { function(); }
int function(){return 0;}
};


/* The constant function is trying to call a non-constant function which could possibly be any value or modify any value.
   Thus the compiler produces an error because the function must be const and it has no way to check if the function it is calling
   remains constant or does not modify any data members or functions in any way. The only way it would be able to check the function to be constant
   would be to apply the const keyword to the declaration of the function being called.*/
