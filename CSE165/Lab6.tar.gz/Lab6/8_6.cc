#include <iostream>
using namespace std;

int main () {
const char carr[] = {'a','b','c'};

carr[0] = '0';
}
/* By declaring an array of chars const you are telling the compiler that you want the contents of the char array to be constant.
   So trying to change the value of the array after the array has been declared and initialized as constant gives a compiler error
   because that breaks the whole idea of constancy. When changing the value, the value then isn't constant anymore and is variable.
   Adding the const keyword helps the compiler enforce that it is constant. */
