#include <iostream>
using namespace std;

int main () {
double da [10] = {1,2,3,4,5,6,7,8,9,10};
int sz = sizeof(da)/sizeof(da[0]);
double* const dp = da;
for (int i = 0; i < sz; i++)
{
 cout << *dp << endl;
//dp++; //trying to change the pointer itself which declared const and cannot change.
 *dp = *dp + 1;
}
  
}

/* When changing what the pointer points to is fine because you are not actually changing the pointer itself
   you are only changing the value that is pointed by the pointer. Now trying to change the pointer itself by incrementing it will cause
   a compiler error because in the process you are trying to change the pointer which was declared constant not the value it points to.*/
