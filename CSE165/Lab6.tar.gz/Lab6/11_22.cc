#include <iostream>
using namespace std;
class X {
X(const X& c); // undefined copy constructor
public:
X(){}
X* clone() const {
return new X(); // returns pointer to new object
}

X* clone2 (const X& old)  {
X* n = old.clone(); // returns pointer to clone of old object
return n;
}

};

int main () {
X x;
X& y = x;
x.clone();
x.clone2(y);
}
