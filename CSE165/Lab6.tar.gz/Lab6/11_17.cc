#include <iostream>
#include <stdlib.h>
using namespace std;

class X {
    double* dop;
public:
    X(const X& c) { //copy constructor // is called when passing the object by value
    dop = new double;
    *dop = *c.dop; 
    }
    X(double dp) { // constructor that takes in double parameter is called when the object is made
    dop = new double;
    *dop = dp;
    }
    ~X(){
     cout << *dop << endl;
     *dop = -1;
     delete dop; // Is called twice once upon exit of the called function and another time when the destructor is called
                 // because of the delete operator within the destructor.
     *dop = 0;
     }
    void func (X x) { }
   
};

int main (int argc, char** argv) {
int arg = atoi(argv[1]);
X x((double) arg);
x.func(x);
}


