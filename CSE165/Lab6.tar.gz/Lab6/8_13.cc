#include <iostream>
using namespace std;

void cfunc(const int val)
{
  val = 20;
}
int main () {
int pval = 10;
cfunc(pval);
}

/* The value passed to the function is passed by value. Even though a copy of the value is passed, it still can not be manipulated within the
   function because the value is taken as a const parameter. This restricts the incoming value to be a constant value whose initialized value cannot
   be changed even when passed by value (i.e. the value passed is a copy of the original value). */
