#include <ctime>
#include <stdio.h>
#include <iostream>
using namespace std;

int main(){

const time_t currTime =time(0);
currTime = time(0);
printf("%s", asctime(localtime(&currTime)));
  
}

/* The const determined at runtime cannot be reassigned a new value because the const keyword prevents the variable from 
   being re-assigned a new value even upon runtime. The const keyword is there for the compiler to ensure that whatever is declared
   constant retains one value initialized upon declaration. This value must remain constant upon declaration and cannot be reassigned
   even during runtime.*/
