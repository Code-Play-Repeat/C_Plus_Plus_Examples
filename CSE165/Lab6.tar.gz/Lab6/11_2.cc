
#include <iostream>
using namespace std;




int main() {

int y;
int& r = y;
const int& q = 12;
int x = 0;
int& a = x;
int* rr = &y;
int* b = &x;

cout << "x = " << x << ", a = " << a << endl;
a++;
cout << "x = " << x << ", a = " << a << endl;

cout << "y = " << y << ", r = " << r << endl;
r++;
cout << "y = " << y << ", r = " << r << endl;

cout << "q = " << q << endl;

cout << "y = " << x << ", rr = " << *rr << endl;
(*rr)++;
cout << "y = " << x << ", rr = " << *rr << endl;

cout << "x = " << x << ", b = " << *b << endl;
(*b)++;
cout << "x = " << x << ", b = " << *b << endl;

} ///:~

