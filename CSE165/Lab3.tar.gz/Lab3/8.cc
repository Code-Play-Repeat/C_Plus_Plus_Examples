#include <stack>
#include <iostream>
#include <fstream>

using namespace std;

int main (int argc, char** argv){
	stack<double> stack1;
        stack<double> stack2;

	//ds.initialize();

	ifstream in (argv[1]);
	double dNum;

        while (in >> dNum)
	stack1.push(dNum);
	
        while (!stack1.empty()){
	stack2.push(stack1.top());
        stack1.pop();
        }
        stack2.pop();
        int i = 1;
  	while (!stack2.empty()){
	cout << "stack.top() " << i << " = " << stack2.top() << endl;
        stack2.pop();
	i++;
	}
	
        
}
