#include <string>
#include <iostream>
using namespace std;
class Video {
  public:
  Video(string label, int bar, bool rentalSt, string rentalDt, string returnDt);
  int barcode;
  string label,rentalDate, returnDate; 
  bool rentalStatus;
  int* fastFw(int start, int end);
  void pause();
  int* rew (int start, int end);
  string getRentalDate();
  string getReturnDate();
  bool getRentalStatus();
  string getLabel();
  int getBarcode();
  void print();
  private:
  void setRentalDate(string newDate);
  void setReturnDate(string newDate);
  void setRentalStatus(bool status);
  void setLabel(string newLabel);
  void setBarcode(int barcode);
  
};
Video::Video (string lb,int bar, bool rentalSt, string rentalDt, string returnDt){
  label = lb;
  barcode = bar;
  rentalStatus = rentalSt;
  rentalDate = rentalDt;
  returnDate = returnDt;
}
void Video::print(){
  cout << "Label: " << label << " | Barcode: " << barcode;
  if (rentalStatus)
    cout << "\nRental Status: True";
  else
    cout << "\nRental Status: False";
  cout << " | Rental Date: " << rentalDate
       << " | Return Date: " << returnDate << endl;
}
