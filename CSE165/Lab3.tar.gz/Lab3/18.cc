#include <iostream>
#include <string>
using namespace std;

char* copyfunction (char* c);

int main(int argc, char** argv) {
char* s;
int x = 0;

while (argv[1][x] != '\000'){
  s[x] = (char)argv[1][x];
x++;
}
char* cp;
cp = copyfunction(s);
int size1 = sizeof(s)/ x;
for (int j = 0; j < size1; j++)
{
	cout << "Original Array = " << s[j] << endl;
        cout << "Array copy = " << cp[j] << endl;
}

cout << "Original array: " << &s << endl;
cout << "Array copy " << &cp << endl;

//delete s;
//delete cp;

return 0;
}

char* copyfunction (char* c) {
int size2 = (sizeof(c)/ sizeof(c[0]));
char* pt = new char[size2];
for (int i = 0; i < size2; i++)
	pt[i] = c[i];
return (pt);
}

