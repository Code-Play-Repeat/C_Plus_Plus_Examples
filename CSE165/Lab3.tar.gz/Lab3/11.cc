#include <iostream>
#include <string>
//#define DEFINE
using namespace std;

int main ()
{
 string str;

 #ifdef DEFINE
 str = "DEFINED";
 #else
 str = "UNDEFINED";
 #endif
 cout << str << endl;
 
}

