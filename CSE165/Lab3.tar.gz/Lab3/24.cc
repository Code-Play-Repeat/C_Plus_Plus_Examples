#include <iostream>
using namespace std;

struct intS{
  int count;
  intS* pt;
  void function (intS &addr, int newCount);
};

void intS::function(intS &addr, int newCount){
 for (int i = 1; i <= newCount; i++)
 {
  intS is = new intS;
  if (i != newCount)
   is.pt = addr;
  else
   is.pt = 0;
  is.count++;
 }
}

int main (int argc, char** argv) {

}
