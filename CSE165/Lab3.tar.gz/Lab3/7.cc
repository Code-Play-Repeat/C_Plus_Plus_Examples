#include "Stash.cc"
#include <iostream>
#include <fstream>

using namespace std;

int main (int argc, char** argv) {

	Stash s;

	s.initialize (sizeof(double));

	ifstream in (argv[1]);
        double d;
     
	while (in >> d)
	  s.add(&d);
	for (int i = 1; i < s.count(); i++)
	cout << "stringStash.fetch(" << i <<") = " << *(double*) s.fetch(i) << endl;

}
