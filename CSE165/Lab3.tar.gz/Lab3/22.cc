#include "Stash.cc"
#include <string>
#include <iostream>
#include <stack>
#include <fstream>
using namespace std;


int main (int argc, char** argv) {

stack<Stash> container;

 ifstream in(argv[1]);
 string line;
 while (getline(in,line))
 {
   Stash* s = new Stash;
   s->add(line.c_str());
   container.push(*s);
 }
 int i = 0;
 while (!container.empty())
 {
   cout << *(char*) (container.top()).fetch(i) << endl;
   container.pop();
   i++;
 }

}

