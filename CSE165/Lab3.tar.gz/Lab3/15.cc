#include <iostream>
using namespace std;

int main (){
char a;
int i;
long int li;
short int si;
float f;
double d;
long double ld;

char* ap;
int* ip;
long int* lip;
short int* sip;
float* fp;
double* dp;
long double* ldp;

cout << "sizeof(char):" << sizeof(a) << endl;
cout << "sizeof(int):" << sizeof(i) << endl;
cout << "sizeof(long int):" << sizeof(li) << endl;
cout << "sizeof(short int):" << sizeof(si) << endl;
cout << "sizeof(float):" << sizeof(f) << endl;
cout << "sizeof(double):" << sizeof(d) << endl;
cout << "sizeof(long double):" << sizeof(ld) << endl;
/*cout << "sizeof(char*): " << sizeof(ap) << endl;
cout << "sizeof(int*): " << sizeof(ip)  << endl;
cout << "sizeof(long int*): " << sizeof(lip)  << endl;
cout << "sizeof(short int*): " << sizeof(sip)  << endl;
cout << "sizeof(float*): " << sizeof(fp)  << endl;
cout << "sizeof(double*): " << sizeof(dp)  << endl;
cout << "sizeof(long double*): " << sizeof(ldp)  << endl;
*/
}
