#include <iostream>
using namespace std;

int main (){
int* i = new int ();
long* l = new long ();
char* c = new char[100];
float* f = new float [100];

cout << "address of int = " << &i << endl;
cout << "address of long = " << &l << endl;
cout << "address of char array = " << &c << endl;
cout << "address of float= " << &f << endl;

delete[] i, l, c, f;

}
