#include <iostream>
using namespace std;

// Stash  with all its member data and functions
struct Stash {
int size;
int quantity; 
int next;
unsigned char* storage;
void initialize(int size);
void cleanup();
int add(const void* element);
void* fetch(int index);
int count();
void inflate(int increase);
}; ///:~

struct StashwoD{
void initialize(int size);
void cleanup();
int add(const void* element);
void* fetch(int index);
int count();
void inflate(int increase);
};

struct StashwoF{
int size;
int quantity; 
int next;
unsigned char* storage;
};

struct StashE{
};

int main (){

cout << "sizeof(Stash):" << sizeof(Stash) << endl;
cout << "sizeof(StashNoFun):" << sizeof(StashwoF) << endl;
cout << "sizeof(StashBlank):" << sizeof(StashE) << endl;
}
/* Explanation: Functions don't actually take space on the stack until runtime. Since the functions don't get called in main, the stack space is never used for the function. So the result of a struct stash without data is the same as if it was an empty struct stash. */
