#include <vector>
//### Stash.h ###
/*This is a redefined Stash.h so that it implements a vector of char*.
  This is the only required change in order to implement a stash with 
  vector<char*> as its underlying structure */
#ifdef STASH_H
#define STASH_H
struct Stash {
int size;
int quantity;
int next;
vector<char*> storage;
void initialize(int size);
int add(const void* element);
void* fetch(int index);
int count();
void inflate(int increase);
void cleanup();
};
#endif
//######:~

#include "Stash.cc"
#include <iostream>
#include <fstream>
using namespace std;

int main (int argc, char** argv) {

	Stash s;

	s.initialize (sizeof(double));

	ifstream in (argv[1]);
        double d;
     
	while (in >> d)
	  s.add(&d);
	for (int i = 1; i < s.count(); i++)
	cout << "stringStash.fetch(" << i <<") = " << *(double*) s.fetch(i) << endl;

}
