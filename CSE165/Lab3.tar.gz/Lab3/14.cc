#include <iostream>
#include <stack>
#include <string>
#include "Video.cc"
using namespace std;

int main (){
stack<Video> container;
Video v1 ("Departed",12356, true,"5/10/2011","Still in use");
Video v2 ("Transformers:Dark of the Moon",515123, false,"Available","N/A");
Video v3 ("Inception",12356, false,"5/10/2011","9/21/2011");
Video v[] = {v1,v2,v3};
int size = sizeof(v)/sizeof(v[0]);

for (int i = size - 1; i >= 0; i--)
  container.push(v[i]);

for (int i = 0; i < size; i++) {
   (container.top()).print();
   cout << endl;
   container.pop();
   }
}
