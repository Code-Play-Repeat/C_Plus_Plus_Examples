#include <iostream>
using namespace std;
int dog=1, cat=2, bird=3, fish=4;
void f(int pet) {
cout << "pet id number: " << pet << endl;
}
int main() {
int i=10, j=20, k=30;
cout << "f(): " << (long)&f << endl;
cout << "dog: " << (long)&dog << endl;
cout << "cat: " << (long)&cat << endl;
cout << "bird: " << (long)&bird << endl;
cout << "fish: " << (long)&fish << endl;
cout << "i: " << (long)&i << endl;
cout << "j: " << (long)&j << endl;
cout << "k: " << (long)&k << endl;
} ///:~

