#include <iostream>
#include <string>

using namespace std;

void modify1 (string* str1, string str2)
{
	
	 *str1 = str2;
}

void  modify2 (string& str2, string str3)
{
	str2 = str3;
}

int main (int argc, char** argv){
string str1 = argv[1];
string str2 = argv[2];
string str3 = argv[3];

modify1(&str1, str2);
cout << str1 << endl;

modify2(str2, str3);
cout << str2 << endl;

}
