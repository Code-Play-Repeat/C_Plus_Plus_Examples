#include <iostream>
#include <stdlib.h>
using namespace std;
/*Answer to question at bottom*/
void print (double* d, int size)
{
	for (int i = 0; i < size ; i++)
	cout << "da["<< i+1 << "]= " << d[i] << endl;
}

int main (){
double da [10] = {0,0,0,0,0,0,0,0,0,0};
unsigned char* uc = reinterpret_cast<unsigned char*> (&da[0]);

for (int i = 0; i < sizeof(da)/sizeof(double); i += sizeof(double))
    uc[i] = 1;

print(reinterpret_cast<double*>(&uc),sizeof(da)/sizeof(double));

}

/*The reason that each element is not 1 is because when you
are modfying the byte you are changing the value at that position of the byte and thus not adding the value of 1 to the element of itself.*/

