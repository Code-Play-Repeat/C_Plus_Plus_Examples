//: C03:ArrayAddresses.cpp
#include <iostream>
using namespace std;

typedef struct {
int i, j, k;
}ThreeDpoint;

int main() {

ThreeDpoint p[10];

cout << "sizeof(ThreeDpoint) = "<< sizeof(ThreeDpoint) << endl;
for(int i = 0; i < 10; i++)
cout << "&p[" << i << "] = " << &p[i] << endl;
} ///:~

