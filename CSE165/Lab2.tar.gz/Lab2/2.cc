#include <iostream>
#include <stdlib.h>

using namespace std;

int main (int argc, char** argv){
	int input = atoi(argv[1]);
	bool prime = true;
	for (int i = 1; i <= input; i++)
	{
		for (int j = 2; j < input/2; j++)
			if (i !=j && i % j ==0)
			{
			   prime = false;
			   break;
			}
		if (prime)
		cout << i << endl;
	
		prime = true;
	}

}
