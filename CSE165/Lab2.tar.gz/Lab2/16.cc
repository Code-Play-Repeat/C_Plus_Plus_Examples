#include <iostream>
using namespace std;

enum Color {
	c1 = 1,
	c2,
	c3,
	c4,
	c5 
};
int main (int argc, char** argv){

	for (int i = 1; i <= (int)c5 ; i++)
	cout << "c" << i << " : " << Color(i) << endl;
}
