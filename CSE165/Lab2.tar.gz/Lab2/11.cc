//: C03:Boolean.cpp
// Relational and logical operators.
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int main(int argc, char** argv) {

ifstream in (argv[1]);
double d;
vector<double> compare;

while (in >> d)
 compare.push_back(d);

cout << "i > j is " << (compare[0] > compare[1]) << endl;
cout << "i < j is " << (compare[0] < compare[1]) << endl;
cout << "i >= j is " << (compare[0] >= compare[1]) << endl;
cout << "i <= j is " << (compare[0] <= compare[1]) << endl;
cout << "i == j is " << (compare[0] == compare[1]) << endl;
cout << "i != j is " << (compare[0] != compare[1]) << endl;
cout << "i && j is " << (compare[0] && compare[1]) << endl;
cout << "i || j is " << (compare[0] || compare[1]) << endl;
cout << " (i < 10) && (j < 10) is " << ((compare[0] < 10) && (compare[1] < 10)) << endl;
} ///:~

