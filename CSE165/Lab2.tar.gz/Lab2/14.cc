//: C03:Ifthen.cpp
// Demonstration of if and if-else conditionals
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
int main(int argc, char** argv) {
ifstream in (argv[1]);
int nums;
vector<int> iv;

while (in >> nums)
     iv.push_back(nums);

string s1 = (iv[0] > 5) ? "It's greater than 5 \n" : "";
string s2 = (iv[0] < 5) ? "It's less than 5 \n" : "";
string s3 = (iv[0] == 5) ? "It's equal to 5 \n" : "";

string st1 = (iv[1] < 10 && iv[1] > 5) ? "5<j<10 \n" : "";
string st2 = (iv[1] < 5 || iv[1] == 5) ? "j<= 5 \n" : "";
string st3 = (iv[1] > 10 || iv[1] == 10) ? "j>=10 \n" : "";

cout << s1 << s2 << s3 << st1 << st2 << st3;
} ///:~


