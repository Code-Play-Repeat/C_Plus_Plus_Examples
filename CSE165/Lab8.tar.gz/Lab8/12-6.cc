#include <iostream>
#include <stdlib.h>
using namespace std;

class Simple
{
 public:
	int i;
	Simple (int ii = 0) : i(ii) {}
	const Simple operator+ (const Simple& right) const {return Simple(i + right.i);}
	const Simple operator- (const Simple& right) const {return Simple(i - right.i);}
	
	friend ostream& operator<<(ostream& os, const Simple& obj);


};
ostream& operator<<(ostream& os, const Simple& obj) {
	os << obj.i;
	os << endl;
	return os;
}

int main (int argc, char** argv)
{
	int a = atoi(argv[1]);
	int b = atoi(argv[2]);
	int c = atoi(argv[3]);
	Simple x (a);
	Simple y (b);
	Simple z (c);
	Simple r1 = x + y + z;
	Simple r2 = x - y + z;
	Simple r3 = x + y - z;
	Simple r4 = x - y - z;
	cout << r1;
	cout << r2;
        cout << r3;
	cout << r4;
}
