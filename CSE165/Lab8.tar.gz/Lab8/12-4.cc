#include <iostream>
#include <stdlib.h>

using namespace std;

class Simple{
public:
	int i;
	Simple(int in) {i = in;}
	~Simple() {}
	//Prefix 
	const Simple& operator++();
	const Simple& operator--();
	//Postfix
	const Simple operator++(int);
	const Simple operator--(int);
	void print(std::ostream& out) const { out << i << endl; }
};

//Prefix
const Simple& Simple::operator++()
{
	++i;
	return *this;
				 
}
const Simple& Simple::operator--()
{
	--i;
	return *this;				 
}
//Postfix
const Simple Simple::operator++(int)
{
	Simple result = *this;
	i++;
	return result;
}				 
const Simple Simple::operator--(int)
{
	Simple result = *this;
	i--;
	return result;
}


int main(int argc, char** argv)
{
	int i = atoi(argv[1]);
	int j = atoi(argv[2]);
	int k = atoi(argv[3]);

	Simple a(i);
	Simple b(j);
	Simple c(k);
	Simple x(i);
	Simple y(j);
	Simple z(k);
	(++a).print(cout);
	(a++).print(cout);
	(++b).print(cout);
	(b++).print(cout);
	(++c).print(cout);
	(c++).print(cout);
	(--x).print(cout);
	(x--).print(cout);
	(--y).print(cout);
	(y--).print(cout);
	(--z).print(cout);
	(z--).print(cout);

}



