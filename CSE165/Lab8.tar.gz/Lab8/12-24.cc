#include <iostream>
#include <string>
using namespace std;

class X {

public:
	string str;
	X(string s):str(s){}
	void print() {cout << str << endl;}
};

class Y {
public:
	X x;
	Y(X s) : x(s){}
	void print() {cout << x.str << endl;}
};

int main (int argc, char** argv)
{
	string str = argv[1];
	X x (str);
	X x1 = x;
	Y y(x);
	Y y1 = y;
	/*x.print();
	x1.print();
	y.print();*/
	y1.print();
}
