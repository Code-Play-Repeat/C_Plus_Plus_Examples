#include <iostream>
#include <stdlib.h>
#include <string>
#include <sstream>
using namespace std;

class Bird {

	public:
		string str;
		static int count;
		Bird(int n): str("Bird #")
		{
			stringstream ss;
			ss << ++count;
			str += ss.str();
		}
		~Bird(){}
		
};
int Bird::count = 0;
class BirdHouse 
{
	public:
	Bird bd1;
	Bird* bd2;
	Bird& bd3;
	BirdHouse(Bird b1, Bird* b2, Bird& b3):bd1(b1), bd2(b2), bd3(b3){}
	friend ostream& operator<<(ostream& os, const BirdHouse& obj);
};

ostream& operator<<(ostream& os, const BirdHouse& obj) {
	os << obj.bd1.str << endl;
}

int main(int argc, char** argv) {

	int n = 3;
	for (int i = 1; i <= n; i++)
	{
		Bird bird(1);
		Bird* bird1 = &bird;
		Bird& bird2 = bird;	
		BirdHouse birdhouse(bird, bird1, bird2);
		cout << birdhouse;
	}
}


