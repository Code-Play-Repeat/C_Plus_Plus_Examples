#include <iostream>
#include <stdlib.h>
#include <string>
#include <sstream>
using namespace std;

class Bird {

	public:
		string str;
		static int count;
		int i;
		Bird();
		Bird(const Bird& b);
		~Bird();
		friend ostream& operator<<(ostream& os, const Bird& obj);
		Bird operator=(Bird);
		
		
};
int Bird::count = 1;
Bird::~Bird() {}
Bird::Bird()
{
	str = "Bird #";
	i = count++;
}
Bird::Bird(const Bird& b)	
{
	str = b.str;
	i = b.i;
}
ostream& operator<<(ostream& os, const Bird& obj) {
	os << obj.str << obj.i << endl;
}

Bird Bird::operator= (Bird b)
{
	str = string(b.str);
	i = b.i;
}

int main (int argc, char** argv) 
{
	int n = atoi(argv[1]);
	Bird* bird[n];
	for (int i = 0; i < n; i++)
		bird[i] = new Bird();
	Bird* flip[n];

	for (int i = 0; i < n; i++)
		flip[i] = bird[n - i - 1];
	for (int i = 0; i < n; i++)
	{
		bird[i] = flip[i];
		cout << *bird[i];
	}
	
	return 0;

}

