#include <iostream>
#include <stdlib.h>
using namespace std;

class Simple
{
 public:
	int i;
	Simple (int ii = 0) : i(ii) {}
	const Simple operator+ (const Simple& right) const {return Simple(i + right.i);}
	const Simple operator- (const Simple& right) const {return Simple(i - right.i);}
	
	void print(ostream& out){ out << i << endl;}

};

int main (int argc, char** argv)
{
	int a = atoi(argv[1]);
	int b = atoi(argv[2]);
	int c = atoi(argv[3]);
	Simple x (a);
	Simple y (b);
	Simple z (c);
	Simple r1 = x + y + z;
	Simple r2 = x - y + z;
	Simple r3 = x + y - z;
	Simple r4 = x - y - z;
	r1.print(cout);
	r2.print(cout);
	r3.print(cout);
	r4.print(cout);
}
