#include <iostream>
#include <stdlib.h>
#include <iomanip>
#include <string>
#include "require.h"
using namespace std;

class Number
{
 public:
	double i;
	Number (double ii = 0) : i(ii) {}
	const Number operator+ (const Number& right) const {return Number(i + right.i);}
	const Number operator- (const Number& right) const {return Number(i - right.i);}
	const Number operator* (const Number& right) const {return Number(i * right.i);}
	const Number operator/ (const Number& right) const {require(right.i != 0, "divide by zero"); return Number(i/right.i);}
	const Number& operator=(const Number& right) {if (this == &right) return *this; this->i = right.i; return *this;}
	operator double () { return i;}
	
	void print(ostream& out){ out << i << endl;}

};


int main (int argc, char** argv)
{
	Number a (atof(argv[1]));
	Number b (atof(argv[2]));
	Number c (atof(argv[3]));
	
	Number r1 = a+b*c/a;
	Number r2 = a/b+b/c+c/a;
	Number r3 = a*b*c+a/b/c;
	Number r4 = a-b*c+b/a-b; // actually -49053
	// cout << i-j*k+j/i-j << endl;  
	// i = 7 k = 70 j = 700 the actual output is -49053 for the last calculation

	r1.print(cout << setprecision(2) << fixed);
	r2.print(cout << setprecision(2) << fixed);
	r3.print(cout << setprecision(9) << fixed);
	r4.print(cout << setprecision(0) << fixed);
}
